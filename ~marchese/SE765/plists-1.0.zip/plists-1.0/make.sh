#!/bin/sh
erl -run make all -run init stop -noshell
