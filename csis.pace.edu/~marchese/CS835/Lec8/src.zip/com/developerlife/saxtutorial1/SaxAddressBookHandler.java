/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.ParserFactory;
import com.sun.xml.parser.Resolver;

/********************************************************************
 <pre>
 <B>SaxAddressBookHandler</B> class extends HandlerBase which provides
 a default implementaion of the DocumentHandler interface (the other 
 interfaces are EntityResolver, DTDHandler, ErrorHandler). Only the 
 methods that are relevant to creating and AddressBook must be 
 overridden.

 Subclassing HandlerBase makes it easier to provide implementations
 of DocumentHandler that do something useful for creating custom 
 object models.

 The DocumentHandler interface has methods defined in it to process
 elements and attributes.
 
 The SaxAddressBookConverter uses this handler class (with the SAX
 parser that it creates). This SAX parser uses this document handler
 implementation to create an AddressBook object from the XML document
 (which is specified in the SaxAddressBookConverter class).
 
 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:41pm

 @see com.developerlife.saxtutorial1.AddressBook
 @see com.developerlife.saxtutorial1.Person
 @see com.developerlife.saxtutorial1.SaxAddressBookConverter
 </pre>
********************************************************************/
public class SaxAddressBookHandler 
extends HandlerBase{
//
// data members
//
private AddressBook ab = new AddressBook();
private Person p = null;              //temp Person ref
private String currentElement = null; //current element name

                         
//
// AddressBook accessor method
//
public AddressBook getAddressBook(){
    return ab;
}
             
//
// HandlerBase method overrides. This is SAX.
//
/*
This method is called when the SAX parser starts reading the document.
It does nothing here.
*/
public void startDocument() throws SAXException{
    debugDisplay( "start doc" );
}


/*
This method is called when the SAX parser finishes reading the
document. It does nothing here.
*/
public void endDocument() throws SAXException{
    debugDisplay( "end doc" );
}
            

/*
This method is called when the SAX parser encounters an open element
tag. Must remember which element tag was just opened (so that the
characters(..) method can do something useful with the data that is
read by the parser.
*/
public void startElement( String name , AttributeList atts ){
    debugDisplay( "<start elem:"+name+">");

    if( name.equalsIgnoreCase("LASTNAME") ) {
        currentElement = "LASTNAME";
    }
    else if( name.equalsIgnoreCase("FIRSTNAME") ) {
        currentElement = "FIRSTNAME";
    }
    else if( name.equalsIgnoreCase("COMPANY") ) {
        currentElement = "COMPANY";
    }
    else if( name.equalsIgnoreCase("EMAIL") ) {
        currentElement = "EMAIL";
    }
    else if( name.equalsIgnoreCase("PERSON") ) {
        p = new Person();
    }

}
                      

/*
This method is called when the SAX parser encounters a close element
tag. If the person tag is closed, then the person objec must be 
added to the AddressBook (ab).
*/
public void endElement( String name ){debugDisplay( "</"+name+">" );
    if( name.equalsIgnoreCase("PERSON") ) {
        ab.addPerson( p );
        p = null;
    }
}
    

/*
This method is called when the SAX parser encounters #PCDATA or CDATA.
It is important to remember which element tag was just opened so that
this data can be put in the right object. 

I had to trim() the textual data and make sure that empty data is 
just ignored.

Also the start index and length integer must be used to retrieve only 
a portion of the data stored in the char[].
*/
public void characters( char ch[], int start, int length ){
    //dont try to read ch[] as it will go on forever, must use the
    //range provided by the SAX parser.
    String value = new String( ch , start , length );
    if(!value.trim().equals("")) {
        //debugDisplay( value );
        
        if( currentElement.equalsIgnoreCase("FIRSTNAME") ) {
            p.setFirstName( value );
        }
        else if( currentElement.equalsIgnoreCase("LASTNAME") ) {
            p.setLastName( value );
        }
        else if( currentElement.equalsIgnoreCase("COMPANY") ) {
            p.setCompany( value );
        }
        else if( currentElement.equalsIgnoreCase("EMAIL") ) {
            p.setEmail( value );
        }
    }
}


//
// misc utility method
//
public void debugDisplay( String s ){
    //System.out.println( s );
}

                                               
}//end class SaxAddressBookHander
