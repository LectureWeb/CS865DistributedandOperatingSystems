/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.awt.*;                  //AWT classes
import java.awt.event.*;            //AWT event classes
import java.util.*;                 //Vectors, etc
import java.text.*;                 //Date formatting
import java.io.*;                   //Serializable, etc
import java.net.*;                  //Network classes 
import javax.swing.*;               //Swing classes
import javax.swing.event.*;         //Swing events
import javax.swing.table.*;         //JTable models
import javax.swing.tree.*;          //JTree models
import javax.swing.border.*;        //JComponent Borders


/********************************************************************
 <pre>
 <B>AddressBookFrame</B> is a simple class that has a main() method.
 It creates a JFrame and displays an AddressBookTableModelAdapter object in
 a JTable.
 
 The AddressBook is created using the SaxAddressBookConverter class.
 Then an AddressBookTableModelAdapter is created given this AddressBook 
 object. Finally this TableModel is rendered in a JTable.

 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:33pm

 @see com.developerlife.saxtutorial1.SaxAddressBookConverter
 @see com.developerlife.saxtutorial1.AddressBookTableModelAdapter
 @see com.developerlife.saxtutorial1.AddressBook
 </pre>
********************************************************************/
public class AddressBookFrame {
//
// main method
//
public static void main( String[] args ){

    new AddressBookFrame();
}

        
//
// default constructor
//
public AddressBookFrame(){
    //create an AddressBook obj using a SaxAddressBookConverter
    AddressBook addressBook = new SaxAddressBookConverter().
        getAddressBook();
    
    //create a TableModel using the AddressBook
    AddressBookTableModelAdapter model = 
        new AddressBookTableModelAdapter( addressBook );
    
    //create a JTable to show the TableModel 
    JTable table = new JTable( model );
    
    //create a JFrame, put the JTable in it (using a JScrollPane)
    JFrame frame = new JFrame( "developerlife.com :: SAX Tutorial 1" );
    frame.setDefaultCloseOperation( WindowConstants.DISPOSE_ON_CLOSE );
    Container c = frame.getContentPane();
    c.setLayout( new BorderLayout() );
    c.add( new JScrollPane( table ) , BorderLayout.CENTER );
    
    //display the JFrame
    frame.addWindowListener( new WindowCloseListener() );
    frame.setBounds( 0 , 0 , 200 , 50 );
    frame.pack();
    frame.show();
}


//
// window closer
//
public class WindowCloseListener extends WindowAdapter{
    /**
     * Invoked when a window has been closed as the result
     * of calling dispose on the window.
     */
    public void windowClosed(WindowEvent e) {
        System.exit(0);
    }
}//end class WindowCloseListener

        
}//end class AddressBookFrame
