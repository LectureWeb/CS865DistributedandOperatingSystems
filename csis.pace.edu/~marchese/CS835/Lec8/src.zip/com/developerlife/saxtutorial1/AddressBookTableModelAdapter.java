/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.awt.*;                  //AWT classes
import java.awt.event.*;            //AWT event classes
import java.util.*;                 //Vectors, etc
import java.io.*;                   //Serializable, etc
import java.net.*;                  //Network classes 
import javax.swing.*;               //Swing classes
import javax.swing.event.*;         //Swing events
import javax.swing.table.*;         //JTable models
import javax.swing.tree.*;          //JTree models
import javax.swing.border.*;        //JComponent Borders

import javax.servlet.*;             //Servlet classes
import javax.servlet.http.*;        //Servlet classes

/********************************************************************
 <pre>
 <B>AddressBookTableModelAdapter</B> is a simple implementation of the 
 TableModel interface on top of the AddressBook class.
 
 This TableModel implementation allows an AddressBook to be VIEWED
 in a JTable. This model is not mutable.
 
 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:33pm

 @see com.developerlife.saxtutorial1.Person
 @see com.developerlife.saxtutorial1.AddressBook
 </pre>
********************************************************************/
public class AddressBookTableModelAdapter
implements TableModel {

//
// Data Members
//
protected java.util.List listeners = new ArrayList();

protected static final Class[] colClasses = {
    String.class , 
    String.class , 
    String.class , 
    String.class 
    };

protected static final String[] colNames = {
    "LASTNAME" , 
    "FIRSTNAME" , 
    "COMPANY" , 
    "EMAIL"
    };

protected static final int LASTNAME_COL = 0 , 
    FIRSTNAME_COL = 1 , 
    COMPANY_COL = 2 , 
    EMAIL_COL = 3;
    
protected AddressBook addressBook;

//
// Constructor
//
public AddressBookTableModelAdapter( AddressBook a ){
    addressBook = a;
}

//
// TableModel impl
//
public int getRowCount(){
    return addressBook.getSize();
}

public int getColumnCount(){
    return colClasses.length;
}

public String getColumnName(int c){
    return colNames[ c ];
}

public Class getColumnClass(int c){
    return colClasses[ c ];
}

public boolean isCellEditable(int r, int c){
    return false;
}

public Object getValueAt(int r, int c){
    //row corresponds to person
    Person p = addressBook.getPerson( r );
    
    //column corresponds to person field
    if( c == LASTNAME_COL ) {
        return p.getLastName();
    }
    else if( c == FIRSTNAME_COL ) {
        return p.getFirstName();
    }
    else if( c == COMPANY_COL ) {
        return p.getCompany();
    }
    else if( c == EMAIL_COL ) {
        return p.getEmail();
    }
    else return "No value for this col";
}


public void setValueAt(Object v, int r, int c){
    if( r == addressBook.getSize() ) return;
}

public void addTableModelListener(TableModelListener l){
    if(!listeners.contains(l)) {
        listeners.add( l );
    }
}

public void removeTableModelListener(TableModelListener l){
    if(listeners.contains(l)) {
        listeners.remove(l);
    }
}

                             
//
// Event Utility Methods
//
public void fireTableChanged(){
    TableModelEvent e = new TableModelEvent( this );

    ArrayList copy = new ArrayList( listeners );
    for(int i=0; i<copy.size(); i++) {
        ((TableModelListener)copy.get(i)).tableChanged( e );
    }
}



}//end class AddressBookTableModelAdapter
