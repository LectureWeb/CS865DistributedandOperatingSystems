/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.util.*;                 //Vectors, etc
import java.io.*;                   //Serializable, etc
import java.net.*;                  //Network classes 

import javax.servlet.*;             //Servlet classes
import javax.servlet.http.*;        //Servlet classes

/********************************************************************
 <pre>
 <B>AddressBookServlet</B> is a simple Servlet that displays an
 AddressBookTableModelAdapter object in HTML.
 
 The AddressBook is created using the SaxAddressBookConverter class.
 Then an AddressBookTableModelAdapter is created given this AddressBook 
 object. Finally this TableModel is rendered in the Servlet using 
 HTML <table> tags.

 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:33pm

 @see com.developerlife.saxtutorial1.SaxAddressBookConverter
 @see com.developerlife.saxtutorial1.AddressBookTableModelAdapter
 @see com.developerlife.saxtutorial1.AddressBook
 </pre>
********************************************************************/
public class AddressBookServlet 
extends HttpServlet {


//
// doGet() method
//
protected void doGet( HttpServletRequest req, 
                      HttpServletResponse res) 
throws ServletException, IOException{
    //create an AddressBook obj using a SaxAddressBookConverter
    AddressBookTableModelAdapter model = new AddressBookTableModelAdapter(
        new SaxAddressBookConverter().getAddressBook() );
      
    //output the HTML to the res.outputstream
    res.setContentType("text/html");

    PrintWriter out = new PrintWriter(res.getOutputStream());
    out.print( "<html>" );
    out.print( "<title>" );
    out.print( "SAX Tutorial Part 1" );
    out.print( "</title>" );
    out.print( "<center>" );
    out.print( "<head><pre>" );
    out.print( "http://beanfactory.com/xml/AddressBook.xml" );
    out.print( "</pre></head><hr>" );
    
    //format the table
    out.print( "<table BORDER=0 CELLSPACING=2 " );
    out.print( "CELLPADDING=10 BGCOLOR=\"#CFCFFF\" >" );
    out.print( "<tr>");
    
    //display table column
    for(int i=0; i < model.getColumnCount(); i++){
       out.print( "<td><b><center>" + 
                  model.getColumnName( i ) +
                  "</center></b></td>" );
    }
    
    out.print( "</tr>" );
    
    //need to iterate the doc to get the fields in it
    for(int r=0; r < model.getRowCount(); r++) {
       out.print( "<tr>" );
    
       for(int c=0; c < model.getColumnCount(); c++) {
           out.print( "<td>" );
           out.print( model.getValueAt( r , c ) );
           out.print( "</td>" );
       }//end for c=0...
       out.print( "</tr>" );
    
    }//end for r=0...
    
    out.print( "</table>" );
    out.print( "<hr>Copyright The Bean Factory, LLC." );
    out.print( " 1998-1999. All Rights Reserved.");
    out.print( "</center>" );
    out.println("</body>");
    out.println("</html>");
    out.flush();
}


}//end class AddressBookServlet
