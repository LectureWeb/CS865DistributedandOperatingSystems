/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

/********************************************************************
 <pre>
 <B>Person</B> is a simple class that contains 4 String objects named
 fname   : first name
 lname   : last name
 company : company name
 email   : email address 

 The Person class is used in the AddressBook class in order to store
 information about persons in the AddressBook. The SAX document
 handler has to create Person objects based on the information in the
 XML documents, and then add them to the AddressBook object.
 
 The Person class has a toXML() method which returns a String that 
 contains the XML representation of the data stored in this Person
 object. This method is used by the AddressBook class to turn the 
 AddressBook into XML.

 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:41pm

 @see com.developerlife.saxtutorial1.AddressBook
 @see com.developerlife.saxtutorial1.AddressBookTableModelAdapter
 @see com.developerlife.saxtutorial1.AddressBookTableServlet
 </pre>
********************************************************************/
public class Person
{
//
// Data Members
//
String fname, lname, company, email;


//
// accessor methods
//
public String getCompany(){return company;}
public String getEmail(){return email;}
public String getFirstName(){return fname;}
public String getLastName(){return lname;}


//
// mutator methods
//
public void setLastName( String s ){lname = s;}
public void setFirstName( String s ){fname = s;}
public void setCompany( String s ){company = s;}
public void setEmail( String s ){email = s;}


//
// toXML() method
//
public String toXML(){
    StringBuffer sb = new StringBuffer();
    sb.append( "<PERSON>\n" );
    sb.append( "\t<LASTNAME>"+lname+"</LASTNAME>\n" );
    sb.append( "\t<FIRSTNAME>"+fname+"</FIRSTNAME>\n" );
    sb.append( "\t<COMPANY>"+company+"</COMPANY>\n" );
    sb.append( "\t<EMAIL>"+email+"</EMAIL>\n" );
    sb.append( "</PERSON>\n" );
    return sb.toString();
}
    

}//end of Person class
