/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.util.*;

/********************************************************************
 <pre>
 <B>AddressBook</B> is a simple class that contains a List of Person
 objects. AddressBook is just a simple adapter class on top of the 
 java.util.List class.
 
 Methods are available to:
 * get a Person object given an index
 * add Person objects to the AddressBook
 * get the number of Person objects in the AddressBook
 * return an XML representation of the information in the AddressBook
   as a String

 The toXML() returns an XML representation of the AddressBook as a 
 String. This method is not only useful for debugging, but it might
 also be a good way to send the XML representation of this object to
 a persistence engine which stores pure XML. The Person class also 
 has a toXML() method which is used by this class.

 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:33pm

 @see java.util.List
 @see com.developerlife.saxtutorial1.Person
 </pre>
********************************************************************/
public class AddressBook
{
//
// Data Members
//
List persons = new java.util.ArrayList();


//
// mutator method
//
public void addPerson( Person p ){
    persons.add( p );
}


//
// accessor methods
//
public int getSize(){
    return persons.size();
}


public Person getPerson( int i ){
    return (Person)persons.get( i );
}


//
// toXML method
//
public String toXML(){
    StringBuffer sb = new StringBuffer();
    sb.append( "<?xml version=\"1.0\"?>\n" );
    sb.append( "<ADDRESSBOOK>\n\n" );
    for(int i=0; i<persons.size(); i++) {
        sb.append( getPerson(i).toXML() );
        sb.append( "\n" );
    }
    sb.append( "</ADDRESSBOOK>" );

    return sb.toString();
}


}//end of AddressBook class


