/********************************************************************
 * Copyright (c) 1999 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/
package com.developerlife.saxtutorial1;

import java.net.*;
import java.io.*;
import org.xml.sax.*;
import com.sun.xml.parser.*;
        
/********************************************************************
 <pre>
 <B>SaxAddressBookConverter</B> class reads an XML document (after    
 creating a SAX parser). Then it uses the AddressBookHandler class to 
 create an AddressBook object.

 This class does the following things:
 * create a SAX parser
 * create a document handler for the SAX parser
 * allow access to the AddressBook objec created in this class
   using the getAddressBook() method.
 
 This class also has the location of the XML document that actually
 contains the address book data. Two locations are included, one is 
 a URL (http://beanfactory.com/xml/AddressBook.xml) and another is a
 filename (stored in the fname variable) that you can overwrite to 
 point to the location of the AddressBook.xml file on your system.
 
 The String variable parserClassName is used to store the class name
 of the SAX Parser that you wish to use. In this example I simply 
 use the Sun SAX Parser. If you wish to use other SAX parsers, you
 simply have to replace this String with the class name of your 
 SAX parser implementation.
 
 The Resolver class is from the Sun SAX parser and it is used to 
 simply create an InputSource from a URL or a file. 
 
 Please note that the SaxAddressBookHandler does the REAL WORK of 
 creating an AddressBook from the XML document. 
 
 @version        1.0
 @author         Nazmul Idris

 Creation Date : 5/23/1999
 Creation Time : 10:41pm

 @see com.developerlife.saxtutorial1.SaxAddressBookHandler
 @see com.sun.xml.parser.Parser
 @see org.xml.sax.Parser
 </pre>
********************************************************************/
public class SaxAddressBookConverter{

        
//data members
private String fname = "d:/src/com/developerlife/saxtutorial1/AddressBook.xml";
private String url   = "http://beanfactory.com/xml/AddressBook.xml";
private String parserClassName = "com.sun.xml.parser.Parser";

private org.xml.sax.Parser      parser;
private SaxAddressBookHandler   handler;
        

//
// constructor
//
public SaxAddressBookConverter(){
    try{
        //create an InputSource from the file
        /*
        InputStreamReader isr = new InputStreamReader(
            new URL( url ).openStream() 
        );
        InputSource is = new InputSource( isr );
        */
            
        InputSource is = Resolver.createInputSource( 
            new File( fname ));
            //new URL( url ) , false );

        //create an documenthandler to create obj model 
        handler = new SaxAddressBookHandler();
        
        //create a SAX parser using SAX interfaces and classes
        parser = getParser( parserClassName ); 
        
        //create document handler to do something useful with the XML
        //document being parsed by the parser.
        parser.setDocumentHandler( handler );
        parser.setErrorHandler( handler );
        parser.parse( is );

        //using document handler display created object model
        System.out.println( handler.getAddressBook().toXML() );
    }
    catch(Throwable t){
        System.out.println( t );
        t.printStackTrace();
    }
}


//
// parser creation method
//
org.xml.sax.Parser getParser( String classname ) 
throws ClassNotFoundException, IllegalAccessException, 
       InstantiationException{
    return org.xml.sax.helpers.ParserFactory.
        makeParser( classname ); 
}
     

//
// accessor methods
//
public AddressBook getAddressBook(){
    return handler.getAddressBook();
}
        
        
}//end class SaxAddressBookConverter
