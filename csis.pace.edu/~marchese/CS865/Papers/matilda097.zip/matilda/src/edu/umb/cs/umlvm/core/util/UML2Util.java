/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on 2005/07/19
 * Contributors: Hiroshi Wada
 * 
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core.util;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.URIConverter;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLParserPool;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLParserPoolImpl;
import org.eclipse.uml2.*;
import org.eclipse.uml2.util.UML2Resource;

public class UML2Util {

	private static ResourceSet RESOURCE_SET = null;
	private static boolean IsInitialized = false;
	private static Map SaveOptions = new HashMap();
	private static Map LoadOptions = new HashMap();
	private static Map ParserFeatures = new HashMap();
	private static XMLParserPool XmlParserPool = new XMLParserPoolImpl();

	private static void registerResourceFactories() {
		RESOURCE_SET.getPackageRegistry().put( UML2Package.eNS_URI, UML2Package.eINSTANCE );
		Map extensionToFactoryMap = RESOURCE_SET.getResourceFactoryRegistry()
				.getExtensionToFactoryMap();
		extensionToFactoryMap.put( UML2Resource.FILE_EXTENSION, UML2Resource.Factory.INSTANCE );
		extensionToFactoryMap.put( "ecore", new EcoreResourceFactoryImpl() );
		extensionToFactoryMap.put( Resource.Factory.Registry.DEFAULT_EXTENSION,
				new XMIResourceFactoryImpl() );
	}

	private static void registerPathmaps( URI uri ) {
		URIConverter.URI_MAP.put( URI.createURI( UML2Resource.LIBRARIES_PATHMAP ), uri
				.appendSegment( "libraries" ).appendSegment( "" ) );

		URIConverter.URI_MAP.put( URI.createURI( UML2Resource.METAMODELS_PATHMAP ), uri
				.appendSegment( "metamodels" ).appendSegment( "" ) );

		URIConverter.URI_MAP.put( URI.createURI( UML2Resource.PROFILES_PATHMAP ), uri
				.appendSegment( "profiles" ).appendSegment( "" ) );
	}

	public static void initialize( URI uri ) {
		/*
		 * if( IsInitialized ) return;
		 */

		RESOURCE_SET = new ResourceSetImpl();
		registerResourceFactories();
		registerPathmaps( uri );

		ParserFeatures.put( "http://xml.org/sax/features/validation", Boolean.FALSE );

		SaveOptions.put( XMLResource.OPTION_FORMATTED, Boolean.FALSE );
		SaveOptions.put( XMLResource.OPTION_PARSER_FEATURES, ParserFeatures );

		LoadOptions.put( XMLResource.OPTION_DEFER_IDREF_RESOLUTION, Boolean.TRUE );
		LoadOptions.put( XMLResource.OPTION_USE_PARSER_POOL, XmlParserPool );
		LoadOptions.put( XMLResource.OPTION_PARSER_FEATURES, ParserFeatures );

		
		IsInitialized = true;
	}

	public static org.eclipse.uml2.Package load( URI uri ) {
		org.eclipse.uml2.Package package_ = null;

		try {
			Resource resource = RESOURCE_SET.getResource( uri, true );

			EList contents = resource.getContents();

			package_ = (org.eclipse.uml2.Package) EcoreUtil.getObjectByType( contents,
					UML2Package.eINSTANCE.getPackage() );

		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit( 1 );
		}

		return package_;
	}

	public static org.eclipse.uml2.Package load( InputStream istream, boolean useZip ) {

		try {
			XMIResource resource =
				(XMIResource) RESOURCE_SET.createResource( URI.createURI( "dummy.uml2" ) );
			resource.setUseZip( useZip );

			resource.load( istream, LoadOptions );

			EList contents = resource.getContents();
			return (org.eclipse.uml2.Package) EcoreUtil.getObjectByType( contents,
					UML2Package.eINSTANCE.getPackage() );

		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit( 1 );
		}

		return null;
	}

	public static void unload( org.eclipse.uml2.Element element ) {
		Resource resource = element.eResource();
		if (resource != null) {
			resource.unload();
		}
	}

	public static void save( org.eclipse.uml2.Package package_, OutputStream ostream, boolean useZip ) {

		try {
			XMIResource resource = (XMIResource) RESOURCE_SET.createResource( URI
					.createURI( "dummy.uml2" ) );
			resource.setUseZip( useZip );
			resource.getContents().add( package_ );
			resource.save( ostream, SaveOptions );
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit( 1 );
		}
	}

	public static void save( org.eclipse.uml2.Package package_, URI uri ) {
		try {
			OutputStream ostream = new FileOutputStream( new File( uri.path() ) );
			save( package_, ostream, false );
		} catch (IOException ex) {
			System.out.println( ex.getMessage() );
		}
	}

	/**
	 * 
	 * 
	 * check if given stereotype is applied to the element
	 * 
	 * @author Adam
	 * 
	 * @param el
	 *            element under question
	 * @param stereotypeName
	 *            name of stereotype that is possibly applied
	 * 
	 * @ret null if not applied, the stereotype if applied
	 */
	public static Stereotype isAppliedStereotype( Element el, String stereotypeName ) {
		return el.getAppliedStereotype( stereotypeName );

		/*
		 * Set appliedSts = el.getAppliedStereotypes ( );
		 * 
		 * Iterator iter = appliedSts.iterator ( );
		 * 
		 * while ( iter.hasNext ( ) ) { Stereotype stereotype = (Stereotype)
		 * iter.next ( );
		 * 
		 * if ( stereotype.getName ( ).equals ( stereotypeName ) ) { return
		 * stereotype; } }
		 * 
		 * return null;
		 */
	}

	/**
	 * retrieve a tag for a given element
	 * 
	 * most likely used for tags in EJB profile
	 * 
	 * assumption: those tags are properties of stereotypes having same name as
	 * the tag for example tag JavaDimensions is a property of <<JavaDimensions>
	 * 
	 * @author Adam
	 * 
	 * @param element
	 *            element with a tag
	 * @param tagName
	 *            tag to be retrieved
	 * @return the obj repr. the value or null if no such tag
	 */
	public static Object isAppliedTag( NamedElement element, String tagName ) {
		Stereotype stereotype = isAppliedStereotype( element, tagName );

		if (stereotype == null) {
			return null;
		}

		Object value = element.getValue( stereotype, tagName );

		return value;
	}

	/**
	 * retrieves Lifeline associated with the event assuming event has one
	 * lifeline associated or return null
	 * 
	 * @param event
	 *            event on the Lifeline
	 * @return Lifeline covering or null
	 */
	public static Lifeline getLifeline( EventOccurrence event ) {
		// should be covering one lifeline
		EList covereds = event.getCovereds();

		if (covereds.size() != 1) {
			return null;
		}

		Lifeline lifeline = (Lifeline) covereds.get( 0 );

		return lifeline;
	}

	/**
	 * return true there is a match is send and receive ends of the Message both
	 * ends must be EventOccurrences and lay on the same lifeline
	 * 
	 * @param message
	 *            to be tested
	 * @return true if it message is a self message and both ends are
	 *         EventOccurrences otherwise return false
	 */
	public static boolean isSelfMessage( Message message ) {
		if (!(message.getSendEvent() instanceof EventOccurrence && message.getReceiveEvent() instanceof EventOccurrence)) {
			return false;
		}

		EventOccurrence sendEvent = (EventOccurrence) message.getSendEvent();
		EventOccurrence receiveEvent = (EventOccurrence) message.getReceiveEvent();

		// should be only 1 covered
		// but check all for match
		EList sendCovereds = sendEvent.getCovereds();
		EList receiveCovereds = receiveEvent.getCovereds();

		for (int i = 0; i < sendCovereds.size(); i++) {
			Lifeline sendCovered = (Lifeline) sendCovereds.get( 0 );

			for (int j = 0; j < receiveCovereds.size(); j++) {
				Lifeline receiveCovered = (Lifeline) receiveCovereds.get( 0 );

				// if ( sendCovered == receiveCovered )
				if ((sendCovered.getName() != null)
						&& sendCovered.getName().equals( receiveCovered.getName() )) {
					return true;
				}
			}
		}

		return false;
	}

}
