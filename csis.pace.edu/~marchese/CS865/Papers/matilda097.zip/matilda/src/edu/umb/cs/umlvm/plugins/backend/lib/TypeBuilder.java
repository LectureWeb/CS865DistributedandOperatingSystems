/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.backend.lib;

import org.eclipse.jdt.core.compiler.*;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jface.text.*;

/**
 * @author Adam
 * 
 * 
 * Utility for parsing methods and field declaration types
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class TypeBuilder {
    /**
     * tokenize and parse string representing type (primitive, simple,
     * qualified, array) and return appropiate type
     * 
     * @author Adam
     * 
     * @param typeStr
     *            string representing type
     * @param unit
     *            CompilationUnit to which new ASTNode will belong to
     * @return Type built up or null if problems parsing
     */
    public static org.eclipse.jdt.core.dom.Type buildFieldType( String typeStr,
            CompilationUnit unit ) throws ModelParsingException {
        // wrap over a fake class declaration to parse the type string
        // and extract the type AST back from it
        String str = "class Fake{";
        typeStr += " fake ; }";
        str += typeStr;

        // System.out.println("got source string: " + str);
        Document document = new Document( str );
        ASTParser parser = ASTParser.newParser( AST.JLS2 );
        parser.setSource( document.get().toCharArray() );

        CompilationUnit astRoot = (CompilationUnit) parser.createAST( null );
        astRoot.recordModifications();

        IProblem[] probs = astRoot.getProblems();
        String problemsMessage = null;

        for (int i = 0; i < probs.length; i++) {
            problemsMessage += (probs[i].getMessage() + "\n");
        }

        if (probs.length > 0) {
            throw new ModelParsingException( typeStr, probs.length
                    + " problem(s) parsing type declaration: "
                    + problemsMessage );
        }

        TypeDeclaration typeDeclaration = (TypeDeclaration) astRoot.types()
                .get( 0 );
        org.eclipse.jdt.core.dom.Type fieldType = typeDeclaration.getFields()[0]
                .getType();

        // delete the parent node, clone to a new tree
        org.eclipse.jdt.core.dom.Type newFieldType = (org.eclipse.jdt.core.dom.Type) ASTNode
                .copySubtree( unit.getAST(), fieldType );

        return newFieldType;
    }

    /**
     * tokenize and parse string representing method ret type (primitive,
     * simple, qualified, array, not void bc already taken care of) and return
     * appropiate type
     * 
     * @author Adam
     * 
     * @param typeStr
     *            string representing method ret type
     * @param unit
     *            CompilationUnit to which new ASTNode will belong to
     * @return Type built up or null if problems parsing
     */
    public static org.eclipse.jdt.core.dom.Type buildMethodRetType(
            String typeStr, CompilationUnit unit ) throws ModelParsingException {
        String str = "class Fake{";
        typeStr += " fake() ; }";
        str += typeStr;

        Document document = new Document( str );
        ASTParser parser = ASTParser.newParser( AST.JLS2 );
        parser.setSource( document.get().toCharArray() );

        CompilationUnit astRoot = (CompilationUnit) parser.createAST( null );

        IProblem[] probs = astRoot.getProblems();
        String problemsMessage = null;

        for (int i = 0; i < probs.length; i++) {
            problemsMessage += (probs[i].getMessage() + "\n");
        }

        if (probs.length > 0) {
            throw new ModelParsingException( typeStr, probs.length
                    + " problems parsing return type declaration: "
                    + problemsMessage );
        }

        TypeDeclaration typeDeclaration = (TypeDeclaration) astRoot.types()
                .get( 0 );
        org.eclipse.jdt.core.dom.Type retType = typeDeclaration.getMethods()[0].getReturnType();

        // delete the parent node, clone to a new tree
        org.eclipse.jdt.core.dom.Type newRetType = (org.eclipse.jdt.core.dom.Type) ASTNode
                .copySubtree( unit.getAST(), retType );

        return newRetType;
    }

    /**
     * tokenize and parse string representing method param type (primitive,
     * simple, qualified, array) and return appropiate type
     * 
     * @author Adam
     * 
     * @param typeStr
     *            string representing method param type
     * @param unit
     *            CompilationUnit to which new ASTNode will belong to
     * @return Type built up or null if problems parsing
     */
    public static org.eclipse.jdt.core.dom.Type buildMethodParamType(
            String typeStr, CompilationUnit unit ) throws ModelParsingException {
        String str = "class FakeClass{ fakeMethod(";
        typeStr += " fakeParam) ; }";
        str += typeStr;

        Document document = new Document( str );
        ASTParser parser = ASTParser.newParser( AST.JLS2 );
        parser.setSource( document.get().toCharArray() );

        CompilationUnit astRoot = (CompilationUnit) parser.createAST( null );

        IProblem[] probs = astRoot.getProblems();
        String problemsMessage = null;

        for (int i = 0; i < probs.length; i++) {
            problemsMessage += (probs[i].getMessage() + "\n");
        }

        if (probs.length > 0) {
            throw new ModelParsingException( typeStr, probs.length
                    + " problems parsing parameter type declaration: "
                    + problemsMessage );
        }

        TypeDeclaration typeDeclaration = (TypeDeclaration) astRoot.types()
                .get( 0 );
        SingleVariableDeclaration decl = (SingleVariableDeclaration) typeDeclaration
                .getMethods()[0].parameters().get( 0 );
        org.eclipse.jdt.core.dom.Type paramType = decl.getType();

        // delete the parent node, clone to a new tree
        org.eclipse.jdt.core.dom.Type newParamType = (org.eclipse.jdt.core.dom.Type) ASTNode
                .copySubtree( unit.getAST(), paramType );

        return newParamType;
    }
}
