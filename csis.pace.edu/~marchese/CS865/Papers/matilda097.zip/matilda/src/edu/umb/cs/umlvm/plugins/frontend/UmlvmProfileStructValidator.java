/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Khatir S, Anu L
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.frontend;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.eclipse.uml2.Class;
import org.eclipse.uml2.Interaction;
import org.eclipse.uml2.Interface;
import org.eclipse.uml2.Model;
import org.eclipse.uml2.Operation;
import org.eclipse.uml2.Parameter;
import org.eclipse.uml2.Property;
import org.eclipse.uml2.Stereotype;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.Profile;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Anu Lall
 * 
 * UMLVMStructureValidator validates the given Model for integrity of Structural
 * diagrams. It implements ValidatorInterface for model validation.
 * 
 */

public class UmlvmProfileStructValidator implements Plugin {
    private Hashtable classList;

    private Hashtable interfaceList;

    private Logger logger;

    private Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
    }

    public void execute() throws UmlvmPluginException {
        try {
            Data data = _pipeline.getBlackboard().readData( "UMLTree" );
            logger = _pipeline.getLogger();
            classList = new Hashtable();
            interfaceList = new Hashtable();
            Model model = (Model) data.getObject();
            if (validateStructure( model )) {
                logger.info( "GIVEN MODEL WITH UMLVM PROFILES"
                        + " APPLIED HAS VALID STRUCTURAL FEATURES" );
            }
            data.discard();

            // pipeline.executeNextPlugin();
        } catch (DataNotFoundException e) {
            throw new UmlvmPluginException(
                    "Model not found on the blackboard " + e.getMessage() );
        } catch (Exception e) {
            throw new UmlvmPluginException(
                    "Unknown exception in UMLVmSeqValidator " + e.getMessage() );
        }

    }

    /*
     * Implementation which walks through the UML tree and validates the
     * structural features of the model in accordance with UMLVM profile rules.
     * If the structural feature does not conform to UMLVM profile, an Exception
     * is thrown.
     * 
     */
    public boolean validateStructure( Model model ) throws Exception {

        boolean UMLVMexecExists = false;

        List mlist = model.getOwnedMembers();
        for (int i = 0; i < mlist.size(); i++) {
            if ((mlist.get( i ) instanceof Class)
                    && !(mlist.get( i ) instanceof Interaction)) {

                Class classObj = (Class) mlist.get( i );
                checkClassName( classObj );
                checkSuperClass( classObj );
                checkInnerClass( classObj );

                Iterator iter = classObj.getAppliedStereotypes().iterator();
                while (iter.hasNext()) {
                    Stereotype classStereo = (Stereotype) iter.next();
                    String stereoName = classStereo.getName();
                    if (stereoName.compareTo( Profile.Matilda.UMLVMexecutable ) == 0) {
                        // System.out.println(classObj.getName() + " has
                        // Sterotype " + stereoName);
                        if (!UMLVMexecExists) {
                            UMLVMexecExists = true;
                            if (!validateClassStereotype( classObj )) {
                                return false;
                            }
                        }
                    } else if (stereoName.compareTo( Profile.EJB.JavaInterface ) == 0) {
                        logger.info( classObj.getName() + "has Stereotype "
                                + stereoName );
                    } else {
                        logger.info( "Not a valid class stereotype " );
                        throw new Exception( "Not a valid class stereotype " );
                    }
                }

                if (!validateAttributeStereotype( classObj )) {
                    return false;
                }
                if (!validateParamStereotype( classObj )) {
                    return false;
                }

            } else if (mlist.get( i ) instanceof Interface) {
                checkInterfaceName( (Interface) mlist.get( i ) );
            }

        }
        return true;
    }

    public boolean checkClassName( Class classObj ) throws Exception {
        String className = classObj.getName();
        if (className != null) {
            // logger.info( "Class Name is: " + className);
            checkUniqueClassName( classObj );
        } else {
            logger.info( "Class Does Not Have A Name" );
            throw new Exception( "Class Does Not Have A Name" );
        }
        return true;
    }

    public boolean checkUniqueClassName( Class classObj ) throws Exception {
        if (classList != null && classList.containsKey( classObj.getName() )) {
            logger.info( "Class with same name exists in the model" );
            throw new Exception( "Class with same name exists in the model" );
        }
        // logger.info( "Adding class name to classList " +
        // classObj.getName());
        classList.put( classObj.getName(), classObj );
        return true;
    }

    public boolean checkSuperClass( Class classObj ) throws Exception {
        List superClassList = classObj.getSuperClasses();
        /*
         * if( superClassList.size() == 0 ) { logger.info( "Class: " +
         * classObj.getName() + " does not have a super class"); }
         */
        if (superClassList.size() > 1) {

            logger.info( "Class: " + classObj.getName()
                    + "has more than one super class" );
            throw new Exception( "Class should only have one Super Class" );
        }
        /*
         * if( superClassList.size() == 1 ) { for( int i = 0; i <
         * superClassList.size(); i++ ) { Class superClass =
         * (Class)superClassList.get(i); logger.info( "Super class Name is: " +
         * superClass.getName()); } }
         */

        return true;
    }

    public boolean checkInnerClass( Class classObj ) throws Exception {
        List innerClassList = classObj.getNestedClassifiers();
        if (innerClassList.size() > 0) {
            logger.info( "Inner Classes Not Supported" );
            throw new Exception( "Inner Classes Not Supported" );
        }
        return true;
    }

    public boolean checkInterfaceName( Interface interfaceObj )
            throws Exception {
        String interfaceName = interfaceObj.getName();
        if (interfaceName != null) {
            // logger.info( "Interface Name is " + interfaceName);
            checkUniqueInterfaceName( interfaceObj );
        } else {
            logger.info( "Interface Does Not Have a Name" );
            throw new Exception( "Interface Does Not Have a Name" );
        }
        return true;
    }

    public boolean checkUniqueInterfaceName( Interface interfaceObj )
            throws Exception {
        if (interfaceList != null
                && interfaceList.containsKey( interfaceObj.getName() )) {
            logger.info( "Interface with same name exists in the model" );
            throw new Exception( "Interface with same name exists in the model" );
        }
        // logger.info( "Adding interface name to interfaceList " +
        // interfaceObj.getName());
        interfaceList.put( interfaceObj.getName(), interfaceObj );
        return true;
    }

    public boolean validateClassStereotype( Class classObj ) throws Exception {
        boolean mainExists = false;
        boolean validMain = false;
        String main = "main";
        List operationsList = classObj.getOwnedOperations();
        for (int i = 0; i < operationsList.size(); i++) {
            if ((((Operation) operationsList.get( i )).getName())
                    .compareTo( main ) == 0) {
                mainExists = true;
                // System.out.println(classObj.getName() + " has a main method
                // ");
                validMain = validateMain( (Operation) (operationsList.get( i )) );
            }

        }
        if (!mainExists) {
            logger.info( "UMLVMexecutable does not have" + " a main method" );
            throw new Exception( "UMLVMexecutable does not have"
                    + " a main method" );
        }

        return validMain;
    }

    private boolean validateMain( Operation oper ) throws Exception {
        // check for visibility - public
        String visibility = oper.getVisibility().getName();
        // System.out.println("visibility is " + visibility);
        if (visibility != "public") {
            logger.info( "visibility of main method " + "is not public" );
            throw new Exception( "visibility of main method "
                    + "should be public" );

            // return false;
        }
        // check for return type - void
        List retList = oper.getReturnResults();
        if (retList.size() != 0) {
            // System.out.println("There should be only one return value");
            logger.info( "main should have a void return type" );
            throw new Exception( "main should have a void return type" );
        }
        /*
         * Parameter retParam = (Parameter) retList.get(0);
         * System.out.println("return param is " + retParam.getName());
         * 
         * if( retParam != null ) { logger.info( "main method should have a " +
         * "void return type "); throw new Exception("main method should have a
         * void" + " return type");
         *  }
         */
        // System.out.println("return type is void");
        // check if operation is static
        if (!oper.isStatic()) {
            logger.info( "main method should be static" );
            throw new Exception( "main method should be static" );
        }
        /*
         * else { System.out.println("main is static"); }
         */
        // check for formal parameters
        List formalParameters = oper.getFormalParameters();
        if (formalParameters.size() != 1) {
            logger.info( "main should have one formal parameter" );
            throw new Exception( "main should have one formal parameter" );
            // return false;

        } else {
            // check for applied Stereotype - JavaDimensions
            Parameter formalParam = (Parameter) formalParameters.get( 0 );
            // System.out.println("name of formal param of main is " +
            // formalParam.getName());
            Set paramStereotypes = formalParam.getAppliedStereotypes();
            if (!paramStereotypes.isEmpty()) {
                Iterator iter = paramStereotypes.iterator();
                int javaDimenValue = 0;
                String str = "JavaDimensions";
                while (iter.hasNext()) {
                    Stereotype paramStereo = (Stereotype) iter.next();
                    if (((paramStereo.getName()).compareTo( str )) != 0) {
                        logger.info( "only allowed stereotpe applied to"
                                + "formal parameter of main is JavaDimensions" );
                        // return false;
                        throw new Exception(
                                "only allowed stereotpe applied to"
                                        + "formal parameter of main is JavaDimensions" );
                    }
                    /*
                     * else { System.out.println("main formal param has
                     * stereotype " + str); }
                     */
                    javaDimenValue++;
                }
                if (javaDimenValue != 1) {
                    logger.info( "Only one instance of JavaDimensios"
                            + "is allowed for each parameter" );
                    // return false;
                    throw new Exception( "Only one instance of JavaDimensios"
                            + "is allowed for each parameter" );
                }
                /*
                 * else { System.out.println("formal param of main has one " +
                 * "instance of JavaDimensions"); }
                 */
                String paramType = formalParam.getType().getName();
                // System.out.println("param type in main is " + paramType);
                String string = "java.lang.String";
                if (paramType.compareTo( string ) != 0) {
                    // return false;
                    logger.info( "param type should be a String" );
                    throw new Exception( "param type should be a String" );
                }
                /*
                 * else { System.out.println("formal param of main is of type " +
                 * string); }
                 */
            }

        }

        // System.out.println("public static void main(String[])exists");
        return true;
    }

    public boolean validateAttributeStereotype( Class classObj )
            throws Exception {
        List attributes = classObj.getAttributes();
        for (int i = 0; i < attributes.size(); i++) {
            Property attribute = (Property) (attributes.get( i ));
            // System.out.println(attribute.getName());
            Set propStereotypes = attribute.getAppliedStereotypes();
            if (!propStereotypes.isEmpty()) {
                Iterator iter = propStereotypes.iterator();
                int javaDimenValue = 0;
                String str = "JavaDimensions";
                while (iter.hasNext()) {
                    Stereotype paramStereotype = (Stereotype) iter.next();

                    if ((paramStereotype.getName()).compareTo( str ) != 0) {
                        logger.info( "only allowed stereotype"
                                + "applied to parameters is JavaDimensions" );
                        throw new Exception( "only allowed stereotype applied"
                                + "to parameters is JavaDimensions" );

                    } else {
                        javaDimenValue++;
                        // System.out.println(classObj.getName() + " " +
                        // attribute.getName() + " has JavaDimensions" +
                        // " stereotype");

                    }
                }

            }
        }
        return true;
    }

    public boolean validateParamStereotype( Class classObj ) throws Exception {
        List operationsList = classObj.getOwnedOperations();
        for (int i = 0; i < operationsList.size(); i++) {
            String str = "JavaDimensions";
            Operation operation = (Operation) (operationsList.get( i ));
            // System.out.println(operation.getName());
            List paramList = operation.getOwnedParameters();
            for (int j = 0; j < paramList.size(); j++) {

                Parameter param = (Parameter) (paramList.get( j ));
                Set paramStereotypes = param.getAppliedStereotypes();
                if (!paramStereotypes.isEmpty()) {
                    Iterator iter = paramStereotypes.iterator();
                    // String str = "JavaDimensions";
                    while (iter.hasNext()) {
                        Stereotype paramStereotype = (Stereotype) iter.next();
                        if (((paramStereotype.getName()).compareTo( str )) != 0) {
                            logger
                                    .info( "only allowed stereotype"
                                            + "applied to parameters is JavaDimensions" );
                            throw new Exception(
                                    "only allowed stereotype applied"
                                            + "to parameters is JavaDimensions" );

                        }
                        /*
                         * else { System.out.println(param.getName()+ " of " +
                         * operation.getName() + " of " + classObj.getName()+ "
                         * has " + " stereotype " + paramStereotype.getName()); }
                         */

                    }

                }
            }

        }
        return true;
    }
}
