/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Khatir S, Anu L
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.frontend;

/*
 * Created on March 20, 2005
 * 
 * TODO To change the template for this generated file go to Window -
 * Preferences - Java - Code Style - Code Templates
 */

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.eclipse.uml2.CombinedFragment;
import org.eclipse.uml2.EventOccurrence;
import org.eclipse.uml2.ExecutionOccurrence;
import org.eclipse.uml2.Gate;
import org.eclipse.uml2.Interaction;
import org.eclipse.uml2.InteractionConstraint;
import org.eclipse.uml2.InteractionFragment;
import org.eclipse.uml2.InteractionOperand;
import org.eclipse.uml2.InteractionOperator;
import org.eclipse.uml2.Lifeline;
import org.eclipse.uml2.Message;
import org.eclipse.uml2.MessageEnd;
import org.eclipse.uml2.MessageSort;
import org.eclipse.uml2.Model;
import org.eclipse.uml2.OpaqueExpression;
import org.eclipse.uml2.Stereotype;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Kathir
 * 
 * UMLVMSeqValidator validates the given model for integerity of Sequence
 * diagrams. It implements ValidatorInterface for general model validation and
 * VMSeqValidationInterface for sequence specific validation elements.
 */
public class UmlvmProfileSeqValidator implements Plugin {
    private Hashtable interactionList;

    private Logger logger;

    private String interacName = "";

    private Lifeline thisLifeline;

    private Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
    }

    /**
     * Implements the method of ValidatorInterface. Invokes the model
     * validation. Walks from the initial interaction node of the model and
     * walks the UML tree structure and validates according to profile
     * requirements.
     * 
     * @see edu.umb.cs.umlvm.umlvalidators.ValidatorInterface#validateModel(org.eclipse.uml2.Model,
     *      edu.umb.cs.umlvm.umlvalidators.LoggerInterface)
     */
    public void execute() throws UmlvmPluginException {
        try {
            Data data = _pipeline.getBlackboard().readData( "UMLTree" );
            logger = _pipeline.getLogger();
            interactionList = new Hashtable();
            Model model = (Model) data.getObject();
            if (validateBehaviour( model )) {
                logger
                        .info( "GIVEN MODEL WITH UMLVM PROFILE APPLIED HAS VALID BEHAVIOUR ENTRIES" );
            }
            data.discard();

        } catch (DataNotFoundException e) {
            throw new UmlvmPluginException(
                    "Model not found on the blackboard " + e.getMessage() );
        } catch (Exception e) {
            throw new UmlvmPluginException(
                    "Unknown exception in UMLVmSeqValidator " + e.getMessage() );
        }

    }

    /**
     * Implementation which walks through the UML tree and validates all
     * Interactions available in accordance with UMLVM profile rules. Gets the
     * list of Interactions and validates each interaction by interaction. If
     * the Interaction does not confirm to UMLVM profile rules, an Exception is
     * thrown.
     */
    public boolean validateBehaviour( Model model ) throws Exception {
        List ownedMemberList = model.getOwnedMembers();
        logger.info( "No of items in list is " + ownedMemberList.size() );
        logger.info( "No of items in list is " + ownedMemberList.size() );

        for (int i = 0; i < ownedMemberList.size(); i++) {
            if (ownedMemberList.get( i ) instanceof Interaction) {
                Interaction interacObj = (Interaction) ownedMemberList.get( i );
                validateInteraction( interacObj );

                List lifeLineList = interacObj.getLifelines();

                for (int j = 0; j < lifeLineList.size(); j++) {
                    Lifeline lObj = (Lifeline) lifeLineList.get( j );
                    validateLifeline( lObj );
                }

                List messageList = interacObj.getMessages();

                for (int k = 0; k < messageList.size(); k++) {
                    Message messageObj = (Message) messageList.get( k );
                    validateMessage( messageObj );
                }

                List fragmentList = interacObj.getFragments();

                for (int l = 0; l < fragmentList.size(); l++) {
                    InteractionFragment frag = (InteractionFragment) fragmentList
                            .get( l );

                    if (frag instanceof EventOccurrence) {
                        validateEventOccurence( (EventOccurrence) frag );
                    } else if (frag instanceof ExecutionOccurrence) {
                        validateExecOccurrence( (ExecutionOccurrence) frag );
                    } else if (frag instanceof CombinedFragment) {
                        validateCombinedFragment( (CombinedFragment) frag );
                    }
                }
            }
        }

        return true;
    }

    /**
     * Detailed validation of Interaction elements in accordance with UMLVM
     * Profile rules. Walks through the interaction and validates its associated
     * Lifeline and its Gates.
     * 
     * @see edu.umb.cs.umlvm.plugins.frontend.UmlvmSeqValidationInterface#validateInteraction(org.eclipse.uml2.Interaction)
     */
    public boolean validateInteraction( Interaction obj ) throws Exception {
        String name = obj.getName();
        int index = name.indexOf( "::" );

        if (index == -1) {
            logger
                    .info( "Name of the interaction should have a qualified name" );
            throw new Exception(
                    "Name of the interaction should have a qualified name" );
        } else {
            if (interactionList.containsKey( name )) {
                logger.info( "Interaction " + name + " already defined" );
                logger.info( "Interaction " + name + " already defined" );
                throw new Exception( "Interaction " + name + " already defined" );
            } else {
                interactionList.put( name, obj );
                logger.info( "Interaction satisfies the name constraint - "
                        + name );
            }
        }

        interacName = name;

        logger.info( "Name of the interaction is " + name );

        if (obj.getOwnedComments() == null || obj.getOwnedComments().size() > 1) {
            logger.info( "Only one comment can be attached to an interaction" );
            throw new Exception(
                    "Only one comment can be attached to an interaction" );
        }

        List lifeLineList = obj.getLifelines();

        if (lifeLineList == null || lifeLineList.size() == 0) {
            logger.info( "Need atleast one lifeline in an interaction" );
            throw new Exception( "Need atleast one lifeline in an interaction" );
        }

        for (int k = 0; k < lifeLineList.size(); k++) {
            logger.info( "Lifeline name is "
                    + ((Lifeline) lifeLineList.get( k )).getName() );
        }

        List gateList = obj.getFormalGates();

        if (gateList == null || gateList.size() < 2) {
            logger.info( "Minimum two gates are required." );
            throw new Exception( "Minimum two gates are required." );
        }

        logger.info( "Interaction " + name
                + " satisfies the minimum 2 gates constraint - "
                + gateList.size() );

        boolean entryGate = false;

        for (int i = 0; i < gateList.size(); i++) {
            Gate interGate = (Gate) gateList.get( i );
            String interacClassName = name.substring( 0, index );
            thisLifeline = obj.getLifeline( "this:" + interacClassName );

            logger.info( "Interaction class name is " + interacClassName + " "
                    + thisLifeline );

            if (!validateInteractionGate( interGate, thisLifeline )) {
                logger.info( "Failure while validating Interaction Gate" );
                throw new Exception(
                        "Failure while validating Interaction Gate" );
            }

            if (interGate.getName().indexOf( "entry_" ) != -1) {
                if (entryGate) {
                    logger.info( "Entry gate already exists in interaction" );
                    throw new Exception(
                            "Entry gate already exists in interaction" );
                }

                logger.info( "Interaction " + name + "has one entry gate - "
                        + interGate.getName() );
                entryGate = true;
            }
        }

        return true;
    }

    /**
     * Validates Interaction gates in accordance with UMLVM Profile validation
     * rules.
     */
    public boolean validateInteractionGate( Gate obj, Lifeline thisLifeline )
            throws Exception {
        EventOccurrence event;
        Lifeline eventLifeline;

        // String interacName = thisLifeline.getInteraction().getName();
        String name = obj.getName();

        if (name == null) {
            logger.info( "Interaction " + interacName
                    + " gate should have a name" );
            throw new Exception( "Interaction " + interacName
                    + " gate should have a name" );
        }

        if (obj.getName().indexOf( "entry_" ) != -1) {
            Message sendMsg = obj.getSendMessage();

            if (sendMsg == null) {
                logger.info( "Send message cannot be null for entry gate" );
                throw new Exception(
                        "Send message cannot be null for entry gate" );
            }

            event = (EventOccurrence) sendMsg.getReceiveEvent();

            if (obj.getReceiveMessage() != null) {
                logger.info( "Entry gate cannot have a receive message" );
                throw new Exception( "Entry gate cannot have a receive message" );
            }

            eventLifeline = (Lifeline) event.getCovereds().get( 0 );

            logger.info( "Interaction " + interacName
                    + " has a valid entry gate - " + obj.getName() );
        } else {
            Message rcvMsg = obj.getReceiveMessage();

            if (rcvMsg == null) {
                logger.info( "Receive message cannot be null for return gate" );
                throw new Exception(
                        "Receive message cannot be null for return gate" );
            }

            event = (EventOccurrence) rcvMsg.getSendEvent();

            if (obj.getSendMessage() != null) {
                logger.info( "Return gate cannot have a send message" );
                throw new Exception( "Return gate cannot have a send message" );
            }

            eventLifeline = (Lifeline) event.getCovereds().get( 0 );

            logger.info( "Interaction " + interacName
                    + " has a valid return gate - " + obj.getName() );
        }

        logger.info( "Lifeline associated with gate is " + eventLifeline + "  "
                + thisLifeline );

        if (eventLifeline != thisLifeline) {
            logger
                    .info( "Gate messages should be connected only to this interaction class lifeline" );
            throw new Exception(
                    "Gate messages should be connected only to this interaction class lifeline" );
        }

        logger.info( "Interaction " + interacName
                + " gates are attached to proper lifeline" );
        return true;
    }

    /**
     * Validates the Lifeline in accordance with UMLVM Profile validation rules.
     * 
     * @see edu.umb.cs.umlvm.plugins.frontend.UmlvmSeqValidationInterface#validateLifeline(org.eclipse.uml2.Lifeline)
     */
    public boolean validateLifeline( Lifeline obj ) throws Exception {
        String lifeLineName = obj.getName();

        logger.info( "Validating life line " + lifeLineName );
        // String interacName = obj.getInteraction().getName();
        int index = interacName.indexOf( "::" );

        if (index == -1) {
            logger.info( "Interaction does not have a class name" );
            throw new Exception( "Interaction does not have a class name" );
        }

        String className = interacName.substring( index + 2, interacName
                .length() );

        logger.info( "Lifeline " + lifeLineName + " has a proper class name" );

        return true;
    }

    /**
     * Validates the message in accordance with UMLVM Profile validation rules.
     * Walks through the messages and validates its associated send and receive
     * events.
     * 
     * @see edu.umb.cs.umlvm.plugins.frontend.UmlvmSeqValidationInterface#validateMessage(org.eclipse.uml2.Message)
     */
    public boolean validateMessage( Message obj ) throws Exception {
        String name = obj.getName();
        Lifeline sendLifeline = null;
        Lifeline rcvLifeline = null;
        boolean createMessage = false;

        logger.info( "Validating message " + obj );

        if (obj.getMessageSort().getValue() != MessageSort.SYNCH_CALL) {
            logger.info( "Message should be a Synch call" );
            throw new Exception( "Message should be a Synch call" );
        }

        logger.info( "Message is a Synch call" );

        /*
         * Commented temporarily. if (obj.getSendEvent() == null) {
         * logger.info("Message should have a send Event associated with it");
         * throw new Exception("Message should have a send Event associated with
         * it"); }
         */

        logger.info( "Message has a send event as expected" );

        if (obj.getSendEvent() != null
                && obj.getSendEvent() instanceof EventOccurrence) {
            sendLifeline = (Lifeline) ((EventOccurrence) obj.getSendEvent())
                    .getCovereds().get( 0 );

            if (name == null) {
                logger.info( "Name of the send message cannot be null" );
                throw new Exception( "Name of the send message cannot be null" );
            }
        }

        /*
         * Commented temporarily. if (obj.getReceiveEvent() == null) {
         * logger.info("Message should have a receive Event associated to it");
         * logger.info( "Qualified name is " + obj.getQualifiedName() + "
         * Interaction Name " + thisLifeline); throw new Exception("Message
         * should have a receive Event associated to it"); }
         */

        if (obj.getReceiveEvent() != null
                && obj.getReceiveEvent() instanceof EventOccurrence) {
            logger.info( "Message has a receive event as expected "
                    + obj.getReceiveEvent().getName() );
            logger.info( "Receive event number of coverds are "
                    + ((EventOccurrence) obj.getReceiveEvent()).getCovereds()
                            .size() );
            rcvLifeline = (Lifeline) ((EventOccurrence) obj.getReceiveEvent())
                    .getCovereds().get( 0 );
            logger.info( "Message " + name + " has a receive event - "
                    + obj.getReceiveEvent().getName() );
            logger.info( "Message " + name + " has a send event - "
                    + obj.getSendEvent().getName() );
        }

        if (rcvLifeline != null && sendLifeline != null
                && sendLifeline.equals( rcvLifeline )) {
            logger.info( "Inside validating self message" );
            if (obj.getArguments() == null || obj.getArguments().size() == 0) {
                logger.info( "Self messages should have an opaque expression" );
                throw new Exception(
                        "Self messages should have an opaque expression" );
            } else {
                logger
                        .info( "Opaque expression for a self message has a valid body" );
            }
        } else {
            logger.info( "Given message is not a self message" );
        }

        if (obj.getArguments() != null && obj.getArguments().size() != 0) {
            if (obj.getArguments().get( 0 ) instanceof OpaqueExpression) {
                OpaqueExpression expr = (OpaqueExpression) obj.getArguments()
                        .get( 0 );

                if (expr.getBody() == null || expr.getBody().equals( "" )) {
                    logger
                            .info( "Body of Opaque expression attached to message cannot be null" );
                    throw new Exception(
                            "Body of Opaque expression attached to message cannot be null" );
                } else {
                    logger
                            .info( "Opaque expression attached to the message has a valid body" );
                }
            }
        }

        MessageEnd event = obj.getSendEvent();

        if (event != null && event instanceof EventOccurrence) {
            if (!validateSendEvent( (EventOccurrence) event )) {
                logger.info( "Send event validation failure" );
                throw new Exception( "Send event validation failure" );
            }
        }

        event = obj.getReceiveEvent();

        if (event != null && event instanceof EventOccurrence) {
            if (!validateRecieveEvent( (EventOccurrence) event )) {
                logger.info( "Receive event validation failure" );
                throw new Exception( "Receive event validation failure" );
            }
        }

        Set stereoList = obj.getAppliedStereotypes();

        if (!stereoList.isEmpty()) {
            Iterator iter = stereoList.iterator();

            if (iter.hasNext()) {
                if (!validateMsgStereotype( (Stereotype) iter.next() )) {
                    return false;
                }
            }
        }

        logger.info( "Message " + obj.getName() + " is valid" );

        return true;
    }

    /*
     * Validates send event in accordance with UMLVM Profile validation rules.
     * Looks for the associated Execution occurences on this event.
     */
    public boolean validateSendEvent( EventOccurrence obj ) throws Exception {
        logger.info( "Validating send event " + obj );
        List startExecList = obj.getStartExecs();

        if (startExecList != null && startExecList.size() > 0) {
            logger.info( "Send event cannot have start execution occurrence" );
            throw new Exception(
                    "Send event cannot have start execution occurrence" );
        }

        Message sendMsg = obj.getSendMessage();

        logger.info( "Message associated with send event is " + sendMsg );

        if (sendMsg.getName().equals( "new" )) {
            List finishExecList = obj.getFinishExecs();

            if (finishExecList != null && finishExecList.size() > 0) {
                logger
                        .info( "Send Event should not start an execution occurence for a NEW message" );
                throw new Exception(
                        "Send Event should not start an execution occurence for a NEW message" );

            }

            logger
                    .info( "Send event "
                            + obj.getName()
                            + " does not have a start execution for a NEW message as required" );
        }

        logger.info( "Send event " + obj.getName()
                + " does not have a start execution as required" );

        return true;
    }

    /*
     * Validates receive event in accordance with UMLVM Profile validation
     * rules. Looks for the associated Execution occurences on this event.
     */
    public boolean validateRecieveEvent( EventOccurrence obj ) throws Exception {
        logger.info( "Validating receive event " + obj );
        List finishExecList = obj.getFinishExecs();

        if (finishExecList != null && finishExecList.size() > 0) {
            logger
                    .info( "Recieve event cannot have finish execution occurence" );
            throw new Exception(
                    "Recieve event cannot have finish execution occurence" );
        }

        logger.info( "Recieve event " + obj.getName()
                + " does not have a finish execution as required" );

        Message receiveMsg = obj.getReceiveMessage();

        if (receiveMsg.getName().equals( "new" )) {
            List startExecList = obj.getStartExecs();

            if (startExecList != null && startExecList.size() > 0) {
                logger
                        .info( "Receive Event should not start an execution occurence for a NEW message" );
                throw new Exception(
                        "Receive Event should not start an execution occurence for a NEW message" );

            }

            logger
                    .info( "Recieve event "
                            + obj.getName()
                            + " does not have a start execution for a NEW message as required" );
        }

        return true;
    }

    public boolean validateEventOccurence( EventOccurrence obj )
            throws Exception {
        /*
         * String name = obj.getName();
         * 
         * if (name == null || name.equals("")) { logger.info("Event occurence
         * should be named"); throw new Exception("Event occurence should be
         * named"); }
         * 
         * logger.info("Event " + obj.getName() + " is a valid event");
         */

        return true;
    }

    /*
     * Validates each Execution occurrence on a Lifeline and looks for the
     * associated start and finish event occurrences.
     * 
     * @see edu.umb.cs.umlvm.umlvalidators.VMSeqValidationInterface#validateExecOccurrence(org.eclipse.uml2.ExecutionOccurrence)
     */
    public boolean validateExecOccurrence( ExecutionOccurrence obj )
            throws Exception {
        String name = obj.getName();
        /*
         * if (name == null || name.equals("")) { logger.info("Execution
         * occurence should be named"); throw new Exception("Execution occurence
         * should be named"); }
         */

        if (obj.getStart() == null) {
            logger
                    .info( "Execution occurrence should have a start event occurrence" );
            throw new Exception(
                    "Execution occurrence should have a start event occurrence" );

        }

        if (obj.getFinish() == null) {
            logger
                    .info( "Execution occurrence should have a finish event occurrence" );
            throw new Exception(
                    "Execution occurrence should have a finish event occurrence" );

        }

        logger.info( "Execution occurence " + name + " is a valid execution" );

        return true;
    }

    /**
     * Validates the Combined fragmenets associated with each main Interaction
     * segment. Looks for the valid Interaction operator in accordance with
     * UMLVM Profile validation rules. Walks through the Interaction element
     * associated within the Combined Fragment and validates them.
     * 
     * @see edu.umb.cs.umlvm.plugins.frontend.UmlvmSeqValidationInterface#validateCombinedFragment(org.eclipse.uml2.CombinedFragment)
     */
    public boolean validateCombinedFragment( CombinedFragment obj )
            throws Exception {
        String name = obj.getName();
        /*
         * if (name == null || name.equals("")) { logger.info("Execution
         * occurence should be named"); throw new Exception("Execution occurence
         * should be named"); }
         */

        InteractionOperator interOper = (InteractionOperator) obj
                .getInteractionOperator();
        int operator = interOper.getValue();

        // logger.info("Interaction operator is " + interOper.get(operator));

        if (operator != InteractionOperator.ALT
                && operator != InteractionOperator.LOOP
                && operator != InteractionOperator.OPT) {
            logger
                    .info( "Given interaction operator is not a allowed operator for combined fragment "
                            + InteractionOperator.get( operator ) );
            throw new Exception(
                    "Given interaction operator is not a allowed operator for combined fragment "
                            + InteractionOperator.get( operator ) );
        }

        logger.info( "Combined fragment " + name
                + " has a proper interaction operator - "
                + InteractionOperator.get( operator ) );

        List operandList = obj.getOperands();

        if (operandList == null || operandList.size() == 0) {
            logger.info( "Need atleast one operand for a combined fragment" );
            throw new Exception(
                    "Need atleast one operand for a combined fragment" );
        }

        for (int i = 0; i < operandList.size(); i++) {
            InteractionOperand operand = (InteractionOperand) operandList
                    .get( i );

            if (operand.getGuard() == null) {
                logger
                        .info( "Every operand should have a guard associated with it" );
            }
        }

        if (operator == InteractionOperator.OPT) {
            if (operandList.size() > 1) {
                logger
                        .info( "Combined fragment operator OPT cannot have only one operand" );
            }
        } else if (operator == InteractionOperator.ALT) {
            int size = operandList.size();
            InteractionConstraint guard = ((InteractionOperand) operandList
                    .get( size - 1 )).getGuard();

            if (!(guard.getSpecification() instanceof OpaqueExpression)) {
                logger
                        .info( "ALT operator of Combined Fragment should have an ELSE case" );
                throw new Exception(
                        "ALT operator of Combined Fragment should have an ELSE case" );
            }

            OpaqueExpression expr = (OpaqueExpression) guard.getSpecification();

            if (!expr.getBody().equals( "else" )) {
                logger
                        .info( "ALT operator of Combined Fragment should have an ELSE case" );
                throw new Exception(
                        "ALT operator of Combined Fragment should have an ELSE case" );
            }
        } else if (operator == InteractionOperator.LOOP) {
            if (operandList.size() > 1) {
                logger
                        .info( "Combined fragment operator OPT cannot have only one operand" );
            }

            InteractionConstraint guard = ((InteractionOperand) operandList
                    .get( 0 )).getGuard();

            if (guard.getMaxint() != null) {
                logger
                        .info( "Loop combined fragment cannot have a MAX constraint" );
                throw new Exception(
                        "Loop combined fragment cannot have a MAX constraint" );
            }

            if (guard.getMinint() != null) {
                logger
                        .info( "Loop combined fragment cannot have MIN constraint" );
                throw new Exception(
                        "Loop combined fragment cannot have MIN constraint" );
            }

            logger.info( "Interaction constraint LOOP is valid" );
        }

        List coveredList = obj.getCovereds();

        if (coveredList == null || coveredList.size() == 0) {
            logger
                    .info( "Combined fragments should specify the covered lifeline" );
            throw new Exception(
                    "Combined fragments should specify the covered lifeline" );
        }

        logger.info( "Combined Fragment " + name
                + " is covered by the lifeline" );

        for (int i = 0; i < operandList.size(); i++) {
            InteractionOperand operand = (InteractionOperand) operandList
                    .get( i );

            List operandFragList = operand.getFragments();

            for (int j = 0; j < operandFragList.size(); j++) {
                InteractionFragment frag = (InteractionFragment) operandFragList
                        .get( j );

                if (frag instanceof Interaction) {
                    validateCFInteraction( (Interaction) frag );
                }
            }
        }

        return true;
    }

    /**
     * Validates the Combined Fragment Interaction element which is similar to
     * the main Interaction validation constraits, in accordance to UMLVM
     * Profile validation.
     */
    public boolean validateCFInteraction( Interaction obj ) throws Exception {
        if (obj.getOwnedComments() == null || obj.getOwnedComments().size() > 1) {
            logger.info( "Only one comment can be attached to an interaction" );
            throw new Exception(
                    "Only one comment can be attached to an interaction" );
        }

        List lifeLineList = obj.getLifelines();

        for (int i = 0; i < lifeLineList.size(); i++) {
            validateLifeline( (Lifeline) lifeLineList.get( i ) );
        }

        List msgList = obj.getMessages();

        for (int j = 0; j < msgList.size(); j++) {
            validateMessage( (Message) msgList.get( j ) );
        }

        List fragmentList = obj.getFragments();

        for (int l = 0; l < fragmentList.size(); l++) {
            InteractionFragment frag = (InteractionFragment) fragmentList
                    .get( l );

            if (frag instanceof EventOccurrence) {
                validateEventOccurence( (EventOccurrence) frag );
            } else if (frag instanceof ExecutionOccurrence) {
                validateExecOccurrence( (ExecutionOccurrence) frag );
            } else if (frag instanceof CombinedFragment) {
                validateCombinedFragment( (CombinedFragment) frag );
            }
        }

        return true;
    }

    /**
     * Validates the allowed stereotype for UMLVM Profile message element.
     * 
     * @param obj
     * @return
     */
    public boolean validateMsgStereotype( Stereotype obj ) {
        if (!(obj.getName().equals( "umlvmexpression" ))) {
            return false;
        }

        return true;
    }

    public boolean validateComment( org.eclipse.uml2.Comment obj ) {
        return true;
    }

    public boolean validateEventOccurrence( EventOccurrence obj ) {
        return true;
    }

    public boolean validateGate( Gate obj ) {
        return true;
    }

    public boolean validateInteracConstraint( InteractionConstraint obj ) {
        return true;
    }

    public boolean validateStereotype( Stereotype obj ) {
        return true;
    }
}
