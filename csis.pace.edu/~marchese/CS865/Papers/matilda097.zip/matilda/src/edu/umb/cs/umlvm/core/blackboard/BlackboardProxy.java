/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.core.blackboard;

import java.io.*;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.uml2.Model;

import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.core.blackboard.data.UMLTree;
import edu.umb.cs.umlvm.core.config.Config;
import edu.umb.cs.umlvm.core.util.UML2Util;
import edu.umb.cs.umlvm.plugins.backend.lib.JastCompilationPackage;

public class BlackboardProxy implements Blackboard {

    String _bbName;
    String _bbHost;
    Blackboard _remoteBlackboard;
    Config _config;
    
    public BlackboardProxy(String bbName, String bbHost, Config config) {
        _bbName = bbName;
        _bbHost = bbHost;
        _config = config;
    }

    public void initialize() {
        System.setSecurityManager( new RMISecurityManager() );
        
        try {
            // TODO: support hosts except localhost
            _remoteBlackboard =
                (Blackboard) Naming.lookup( "rmi://" + _bbHost + "/" + _bbName );
        } catch (MalformedURLException ex) {
            System.err.println( _bbName + " cannot be found." );
            ex.printStackTrace();
            System.exit( 0 );
        } catch (NotBoundException ex) {
            System.err.println( _bbName + " cannot be found." );
            ex.printStackTrace();
            System.exit( 0 );
        } catch (RemoteException ex) {
            ex.printStackTrace();
            System.exit( 0 );
        }

        // get the path to UML2 resource
        String uml2resource = _config.getParam( "uml2resource" );

        UML2Util.initialize(
                URI.createURI( "jar:file:/" + uml2resource + "!/" ) );
    }

    public void writeData(String dataID, Object data) {
        // send XMI data
		if(data instanceof Model) {
		    try {
                ByteArrayOutputStream ostream = new ByteArrayOutputStream();
                // UML2Util.save( (Model)data, ostream, true );
                UML2Util.save( (Model)data, ostream, false );
                
                _remoteBlackboard.writeData(dataID, ostream.toByteArray());
                
                System.out.println( "gendata: " + ostream.size() );
                
                ostream.close();
            } catch (IOException ex) {
                System.out.println( ex.getMessage() );
            }
		}
        else {
            try {
                if(data instanceof JastCompilationPackage) {
                    ((JastCompilationPackage)data).serialize();
                    System.out.println(
                            "gendata: " + ((JastCompilationPackage)data).getSize() );
                }

                _remoteBlackboard.writeData(dataID, data);
            }
            catch( Exception ex ) {
                ex.printStackTrace();
            }
        }
	}    

    
    public Data readData( String DataID )
        throws DataNotFoundException {
    	
        Data pipelinedata = null;
        try {
            pipelinedata = _remoteBlackboard.readData( DataID );
        } catch (RemoteException ex) {
            ex.printStackTrace();
            System.exit( 0 );
        }

        // System.out.println( "reading data from bb: " + stopwatch.getElapsedTime() );
        
        Object data = pipelinedata.getObject();

        // TODO: Add some identifier of UML model
        if (data instanceof byte[]) {
            
            try {
                InputStream istream =
                    new BufferedInputStream(
                            new ByteArrayInputStream( (byte[])data ) );
                
                // Model model = (Model)UML2Util.load( istream, true );
                Model model = (Model)UML2Util.load( istream, false );
                istream.close();
                
                return new UMLTree( (Model)model );

            } catch (IOException ex) {
                System.out.println( ex.getMessage() );
            }
        }
        else {
            return pipelinedata;
        }

        throw new DataNotFoundException( "Blackboard: Missing Data" );
    }
}
