/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Khatir S, Anu L
 * 
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.frontend;

import java.util.HashMap;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.emf.common.util.BasicDiagnostic;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EAnnotationImpl;
import org.eclipse.emf.ecore.impl.EStringToStringMapEntryImpl;
import org.eclipse.uml2.Model;
import org.eclipse.uml2.util.UML2Validator;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Adam
 * 
 * validate UML2 model in Resource with UML2 Superstructure uses EMF UML2
 * Validator on every model element print model errors
 * 
 */
public class UmlMetamodelValidator extends UML2Validator implements
        MetamodelValidatorInterface, Plugin {
    protected Pipeline _pipeline;

    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            Data data = bb.readData( "UMLTree" );

            if (data == null) {
                throw new DataNotFoundException(
                        "Model data not found or invalid object type.  Expecting org.eclipse.um2.Model" );
            }

            // validate
            Model model = (Model) data.getObject();
            // System.out.println( "1) : " + Footprint.getUsedMemory( true ) );
            IStatus status = validate( model );
            // System.out.println( "2) : " + Footprint.getUsedMemory( true ) );
            data.discard();

            // tree shall remain unchanged
            // exec next plugin if no validation errors
            if (status.isOK()) {
                // pipelineinstance.executeNextPlugin ( );
            } else {
                _pipeline.getLogger().severe(
                        "STOPPING UmlMetamodelValidator due to model errors" );
            }
        } catch (Exception e) {
            // e.printStackTrace ( );
            throw new UmlvmPluginException( "UmlMetamodelValidator Plugin" );
        }
    }

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
    }

    /**
     * validate UML2 model with UML2 Superstructure
     * 
     * @param model
     *            UML2 model
     * @ret status resulting from validation
     */
    public IStatus validate( Object model ) {
        Model umlmodel = (Model) model;
        _pipeline.getLogger().info(
                "validating user model with UML2.0 Metamodel" );

        // validate the model
        BasicDiagnostic diag = new BasicDiagnostic(
                "UML SuperStructure Validator", 0, "", null );
        HashMap cache = new HashMap();

        // validation result, add to diagnostic chain
        boolean passed = true;

        TreeIterator modelIterator = umlmodel.eAllContents();

        while (modelIterator.hasNext()) {
            Object element = modelIterator.next();

            if (!(element instanceof EAnnotationImpl || element instanceof EStringToStringMapEntryImpl)) {
                EClass eclass = ((EObject) element).eClass();
                int classID = ((EClassifier) eclass).getClassifierID();

                try {
                    // passed &= validate ( classID, element, diag, cache );
                    passed &= validate( classID, element, diag, null );
                } catch (Exception e) {
                    _pipeline.getLogger().warning(
                            e + " caused by unsupported element: " + element );
                }
            }
        }

        String mess;
        BasicDiagnostic diag2;

        if (passed) {
            mess = "model conforms to UML2 Superstructure";
            diag2 = new BasicDiagnostic( "UML SuperStructure Validator", 0,
                    mess, null );
        } else {
            mess = "model does not conform to UML2 Superstructure:  ";
            diag2 = new BasicDiagnostic( "UML SuperStructure Validator", 1,
                    mess, null );
        }

        diag.add( diag2 );

        IStatus status = BasicDiagnostic.toIStatus( diag );

        // diagnostics resulting from validation failure
        if (!status.isOK()) {
            for (int i = 0; i < status.getChildren().length; i++) {
                _pipeline.getLogger().warning(
                        status.getChildren()[i].getMessage() );
            }
        } else {
            _pipeline.getLogger().info( mess );
        }

        return status;
    }
}
