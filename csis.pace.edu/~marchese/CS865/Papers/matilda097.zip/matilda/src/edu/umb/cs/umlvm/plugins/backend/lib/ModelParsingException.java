/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.backend.lib;

import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Adam
 * 
 * exception thrown by type and block builders when expression / tokens parsed
 * is invalid expression as per ASTParser
 */
public class ModelParsingException extends UmlvmPluginException {
    /**
     * @param message
     */
    public ModelParsingException(String message) {
        super( message );
    }

    public ModelParsingException(String expression, String message) {
        super( "Unable to parse: |" + expression + "|\n" + message );
    }
}
