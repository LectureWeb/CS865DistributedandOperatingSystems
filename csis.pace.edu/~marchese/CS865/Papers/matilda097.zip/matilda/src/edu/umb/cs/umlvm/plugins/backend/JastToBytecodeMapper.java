/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Adam M
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.backend;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.internal.compiler.batch.Main;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.core.util.JDTUtil;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;
import edu.umb.cs.umlvm.plugins.backend.lib.JastCompilationPackage;

/**
 * @author Adam
 * 
 * uses compiler (jdt or javac) to compile Java source to Java byte-code
 * 
 * previously produced JAST tree was already checked for syntax source code is
 * generated from the JAST delete source code from cache after compiled
 * 
 * 
 * TODO use only compiler backend for semantic analysis and code gen instead of
 * going back from JAST tree to source code and compiling source code
 * 
 */
public class JastToBytecodeMapper implements Plugin {
    public static boolean DEBUG = false;

    // temporary location for model sources and class files
    private String execDirName = "UMLVM_model_exec_cache";

    private String compiler = "jdt"; // compiler to use, jdt|javac

    protected Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;

        try {
            execDirName = System.getProperty( "java.io.tmpdir" );
            execDirName += File.separator + "UMLVM_classes";
        } catch (SecurityException e) {
            // no need to handle, keep default umlvm root directory
        }
    }

    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            // get JAST tree
            Data data = bb.readData( "JAST Tree" );

            if (data == null) {
                throw new DataNotFoundException(
                        "Model data not found or invalid object type.  Expecting umlvm.plugins.backend.JastCompilationPackage" );
            }

            // get options
            compiler = _pipeline.getConfig().getParam( this.getClass().getName(), "compiler" );

            JastCompilationPackage jastPackage = (JastCompilationPackage) data.getObject();

            _pipeline
                    .getLogger()
                    .info(
                            "JastValidator starting to validate jast semantics and generate Java byte-code" );

            // validate JAST, write out byte code
            File[] classFiles = jastToBytecode( jastPackage );

            if (compilationSuccess( classFiles )) {
                // write the files array to data storage
                bb.writeData( "class files", classFiles );
            } else {
                _pipeline.getLogger().severe( "Model compilation errors, STOPPING" );
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new UmlvmPluginException( "JastValidator Plugin" );
        }
    }

    /**
     * validate JAST trees contained within the package write any error/warnings
     * if validation passes write out byte-code as class files
     * 
     * @param jastPackage
     *            package containing JAST trees for validation and byte-code
     *            conversion
     * @return array of class Files created as result of compilation
     */
    public File[] jastToBytecode( JastCompilationPackage jastPackage ) throws UmlvmPluginException {
        File[] sources = writeSource( jastPackage );

        // compile
        File[] byteCodes = compile( sources );

        if (DEBUG) {
            for (int i = 0; i < byteCodes.length; i++) {
                System.out.println( byteCodes[i].getAbsolutePath() );
            }

            System.out.println( "number of class files: " + new Integer( byteCodes.length ) );
        }

        // delete sources
        try {
            for (int i = 0; i < sources.length; i++) {
                // sources[i].delete ( );
            }
        } catch (SecurityException e) {
        }

        return byteCodes;
    }

    // compile all sources passed
    // put class files in same dir as sources
    // return File [] repr. class files
    private File[] compile( File[] sources ) {
        File[] classes = new File[sources.length];

        StringBuffer sbSources = new StringBuffer();

        for (int i = 0; i < sources.length; i++) {
            String sourceFileName = sources[i].getName();

            String compileFilePath = new String( execDirName + File.separator + sourceFileName );

            // place class File into array
            String classFilePath = compileFilePath.replaceAll( ".java", ".class" );
            classes[i] = new File( classFilePath );

            sbSources.append( compileFilePath + " " );
        }

        String sourcesStr = sbSources.toString();

        if (compiler.equals( "jdt" )) {
            // compile with JDT compiler
            if (DEBUG) {
                System.out.println( "using jdt" );
            }

            Main.compile( "-1.4  " + sourcesStr );
            // System.out.println("The COmpile string:"+sourcesStr);
        } else if (compiler.equals( "javac" )) {
            // compile with javac compiler
            if (DEBUG) {
                System.out.println( "using javac" );
            }

            try {
                Runtime rt = Runtime.getRuntime();

                Process process = rt.exec( "javac " + sourcesStr );

                InputStreamReader reader = new InputStreamReader( process.getInputStream() );

                BufferedReader buf_reader = new BufferedReader( reader );

                String line;

                while ((line = buf_reader.readLine()) != null) {
                    // System.out.println ( line );
                }
            } catch (IOException e) {
                System.out.println( e );
            } catch (Exception e) {
                System.out.println( e + "\ncheck if javac is in your PATH" );
            }
        }

        return classes;
    }

    // write compilation units to java files
    // return array of files created
    private File[] writeSource( JastCompilationPackage jastPackage ) throws UmlvmPluginException {
        // create a file for each compilation unit in execDir directory
        Collection<String> cUnitsNames = jastPackage.getClassNames();
        File execDir = new File( execDirName );

        // delete the dir and files in it
        try {
            deleteDirRec( execDir );
        } catch (SecurityException e) {
            throw new UmlvmPluginException( "unable to delete old source directory "
                    + execDir.getAbsolutePath() );
        }

        // Create a directory;
        try {
            execDir.mkdir();
        } catch (SecurityException e) {
            throw new UmlvmPluginException( e + ", cannot create directory: "
                    + execDir.getAbsolutePath() );
        }

        // create File for each CompilationUnit
        ArrayList cFiles = new ArrayList(); // colection of Files

        Iterator<String> it = cUnitsNames.iterator();
        while (it.hasNext()) {
            String unitName = it.next();
            File cFile = new File( execDir.getAbsolutePath() + File.separator + unitName + ".java" );
            cFiles.add( cFile );

            cFile.deleteOnExit();
            /*
            CompilationUnit cUnit = (CompilationUnit) jastPackage.getUnit( unitName );
            String cUnitSource = JDTUtil.CompilationUnit2Source( cUnit );
            */
            CompilationUnit unit = (CompilationUnit)jastPackage.getUnit( unitName );
            String cUnitSource = JDTUtil.CompilationUnit2Source(unit);

            try {
                Writer out = new BufferedWriter( new FileWriter( cFile.getAbsoluteFile() ) );
                out.write( cUnitSource );
                out.close();
            } catch (IOException e) {
                throw new UmlvmPluginException( "Unable to write to temp source file "
                        + cFile.getAbsolutePath() );
            }
        }

        return (File[]) cFiles.toArray( new File[0] );
    }

    // delete cache directory recursively
    public static void deleteDirRec( File dir ) throws SecurityException {
        if (dir.isDirectory()) {
            String[] children = dir.list();

            for (int i = 0; i < children.length; i++) {
                deleteDirRec( new File( dir, children[i] ) );
            }

            dir.delete();
        } else {
            dir.delete();
        }
    }

    // return true if every class file exist, i.e. compilation was successful
    private boolean compilationSuccess( File[] classFiles ) {
        for (int i = 0; i < classFiles.length; i++) {
            File classFile = classFiles[i];

            if (!classFile.exists()) {
                return false;
            }
        }

        return true;
    }
}
