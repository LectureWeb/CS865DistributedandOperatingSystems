/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki
 * 
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core;

import java.awt.*;
import java.io.*;
import javax.swing.*;

/*
 * Created on Feb 28, 2005
 * 
 * TODO To change the template for this generated file go to Window -
 * Preferences - Java - Code Style - Code Templates
 */

/**
 * @author EMMadhuBabu
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */

public class Console extends JFrame {
    PipedInputStream piOut;

    PipedInputStream piErr;

    PipedOutputStream poOut;

    PipedOutputStream poErr;

    JTextArea textArea = new JTextArea();

    public Console() throws IOException {
        // Set up System.out
        super( "UML Virtual Machine - Console" );
        piOut = new PipedInputStream();
        poOut = new PipedOutputStream( piOut );
        System.setOut( new PrintStream( poOut, true ) );

        // Set up System.err
        piErr = new PipedInputStream();
        poErr = new PipedOutputStream( piErr );
        System.setErr( new PrintStream( poErr, true ) );

        // Add a scrolling text area
        textArea.setEditable( false );
        textArea.setRows( 25 );
        textArea.setColumns( 80 );
        getContentPane().add( new JScrollPane( textArea ), BorderLayout.CENTER );
        pack();
        setVisible( true );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        // Create reader threads
        new ReaderThread( piOut ).start();
        new ReaderThread( piErr ).start();
    }

    public void startConsole() {

    }

    class ReaderThread extends Thread {
        PipedInputStream pi;

        ReaderThread(PipedInputStream pi) {
            this.pi = pi;
        }

        public void run() {
            final byte[] buf = new byte[1024];
            try {
                while (true) {
                    final int len = pi.read( buf );
                    if (len == -1) {
                        break;
                    }
                    SwingUtilities.invokeLater( new Runnable() {
                        public void run() {
                            textArea.append( new String( buf, 0, len ) );

                            // Make sure the last line is always visible
                            textArea.setCaretPosition( textArea.getDocument()
                                    .getLength() );

                        }
                    } );
                }
            } catch (IOException e) {
            }
        }
    }
}
