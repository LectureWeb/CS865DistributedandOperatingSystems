/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Khatir S, Anu L
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.frontend;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.emf.common.util.URI;
import org.eclipse.uml2.Model;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.util.UML2Util;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Adam
 * 
 * load XMI model and corresponding resources (profiles, metamodel) create UML2
 * Resource for the model and make it available in the storage
 * 
 */
public class ModelLoader implements ModelLoaderInterface, Plugin {

    protected Pipeline _pipeline;
    private List _loadedModels = new LinkedList();

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
    }

    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            String modelFileName = _pipeline.getConfig().getParam(
                    this.getClass().getName(), "Model Filename" );

            Model model = (Model) load( modelFileName );
            bb.writeData( "UMLTree", model );
            UML2Util.unload( model );
        } catch (Exception e) {
            // e.printStackTrace ( );
            throw new UmlvmPluginException(
                    "Model Loader Plugin unable to load model, STOPPED.  "
                            + e.getMessage() );
        }
    }

    /**
     * @param filename
     *            path to XMI2.0 file with model
     * @ret loaded Model
     */
    public Model load( String filename ) throws DataNotFoundException {
        if (filename == null) {
            throw new DataNotFoundException( "need filename to load model" );
        }

        File file = new File( filename );

        if (!file.exists()) {
            throw new DataNotFoundException( "model file does not exist" );
        }

        if (!file.canRead()) {
            throw new DataNotFoundException(
                    "check model file read permissions" );
        }

        // get the path to UML2 resource
        String uml2resource = _pipeline.getConfig().getParam( "uml2resource" );

        UML2Util.initialize(
                URI.createURI( "jar:file:/" + uml2resource + "!/" ) );

        return (Model) UML2Util.load( URI.createURI( filename ) );
    }
}
