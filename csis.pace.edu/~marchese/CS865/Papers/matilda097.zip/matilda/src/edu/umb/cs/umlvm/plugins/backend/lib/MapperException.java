/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.backend.lib;

import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

import org.eclipse.uml2.Class;
import org.eclipse.uml2.Element;
import org.eclipse.uml2.Interaction;

/**
 * @author Adam
 * 
 * 
 * Exception thrown by UmlAstMappers
 * 
 */
public class MapperException extends UmlvmPluginException {
    public MapperException(String message) {
        super( message );
    }

    public MapperException(Element element) {
        super( "Error caused by mapping of: " + element );
    }

    public MapperException(Element element, Class umlClass) {
        super( "Error caused by mapping of: " + element + "\nin Class: " + umlClass );
    }

    public MapperException(Element element, Interaction umlInter) {
        super( "Error caused by mapping of: " + element + "\nin Interaction: " + umlInter );
    }

    public MapperException(Element element, String message) {
        super( message + " caused by mapping of: " + element );
    }

    public MapperException(Element element, Class umlClass, String message) {
        super( message + " caused by mapping of: " + element + "\nin Class: " + umlClass );
    }

    public MapperException(Element element, Interaction umlInter, String message) {
        super( message + " caused by mapping of: " + element + "\nin Interaction: " + umlInter );
    }
}
