/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on 2005/09/30
 * Contributors: Hiroshi Wada
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.util;

public class Footprint {

    private static void runGC() {
        runGC( 100, 3 );
    }

    private static void runGC( int count, int maxUnupdatedTerm ) {
        Runtime runtime = Runtime.getRuntime();
        long usedMemory = 0;
        long minUsedMemory = Long.MAX_VALUE;
        int unupdatedTerm = 0;
        int c = 0;

        do {
            System.runFinalization();
            System.gc();
            Thread.currentThread().yield();
            usedMemory = runtime.totalMemory() - runtime.freeMemory();

            if (usedMemory < minUsedMemory) {
                minUsedMemory = usedMemory;
                unupdatedTerm = 0;
            } else {
                unupdatedTerm++;
            }

            c++;
            // System.out.println( c + " : " + usedMemory );
        } while (unupdatedTerm < maxUnupdatedTerm && c < count);
    }

    public static long getUsedMemory( boolean runGC ) {
        Runtime runtime = Runtime.getRuntime();
        if (runGC) {
            runGC();
        }

        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        return usedMemory;
    }

    /*
     * // for testing this class public static void main (String[] args) {
     * System.out.println("calculating memory availability..."); Runtime runtime =
     * Runtime.getRuntime(); System.out.println( "Total memory space: " +
     * runtime.totalMemory() ); //System.out.println( "Max memory space: " +
     * runtime.maxMemory() ); System.out.println( "Free memory space: " +
     * runtime.freeMemory() ); Stopwatch sw = new Stopwatch(); sw.start();
     * edu.uci.ics.bionet.util.analysis.Footprint footprint = new
     * edu.uci.ics.bionet.util.analysis.Footprint(); System.out.println( "Memory
     * footprint: " + footprint.getUsedMemory() ); sw.stop();
     * System.out.println( "Time to calculate memory footprint: " +
     * sw.getElapsedTime() );
     * 
     * System.out.println( "Total memory space: " + runtime.totalMemory() );
     * //System.out.println( "Max memory space: " + runtime.maxMemory() );
     * System.out.println( "Free memory space: " + runtime.freeMemory() ); }
     */
}
