/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Adam M
 * 
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.backend;

import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ArrayType;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CharacterLiteral;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.Name;
import org.eclipse.jdt.core.dom.PrimitiveType;
import org.eclipse.jdt.core.dom.QualifiedType;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jface.text.Document;
import org.eclipse.uml2.Activity;
import org.eclipse.uml2.AssociationClass;
import org.eclipse.uml2.Behavior;
import org.eclipse.uml2.Class;
import org.eclipse.uml2.Classifier;
import org.eclipse.uml2.Component;
import org.eclipse.uml2.Device;
import org.eclipse.uml2.ExecutionEnvironment;
import org.eclipse.uml2.Generalization;
import org.eclipse.uml2.Implementation;
import org.eclipse.uml2.Interaction;
import org.eclipse.uml2.Interface;
import org.eclipse.uml2.Model;
import org.eclipse.uml2.NamedElement;
import org.eclipse.uml2.Node;
import org.eclipse.uml2.Operation;
import org.eclipse.uml2.Parameter;
import org.eclipse.uml2.ParameterDirectionKind;
import org.eclipse.uml2.Property;
import org.eclipse.uml2.ProtocolStateMachine;
import org.eclipse.uml2.StateMachine;
import org.eclipse.uml2.Stereotype;
import org.eclipse.uml2.VisibilityKind;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.core.util.UML2Util;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.Profile;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;
import edu.umb.cs.umlvm.plugins.backend.lib.JastCompilationPackage;
import edu.umb.cs.umlvm.plugins.backend.lib.MapperException;
import edu.umb.cs.umlvm.plugins.backend.lib.ModelParsingException;
import edu.umb.cs.umlvm.plugins.backend.lib.TypeBuilder;
import edu.umb.cs.umlvm.plugins.backend.lib.UmlToJastMappings;

/**
 * 
 * @author Adam
 * 
 * Map UML model to JAST tree create that JAST tree first map the Class diagram
 * to TypeDeclarations within CompilationPackage also create MethodDeclarations
 * and FieldDecls
 * 
 */
public class ClassDiagramToJastMapper implements UML2ASTMapper, Plugin {
    private CompilationUnit curUnit; // curent compilation unit under works

    private UmlToJastMappings mappings; // UML -> JAST mappings used for
                                        // debugger plugin

    protected Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        mappings = new UmlToJastMappings();
        _pipeline = pipeline;
    }

    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            Data data = bb.readData( "UMLTree" );

            if (data == null) {
                throw new DataNotFoundException(
                        "Model data not found or invalid object type.  Expecting org.eclipse.um2.Model" );
            }

            Model model = (Model) data.getObject();

            _pipeline.getLogger().info(
                    "ClassDiagramToJastMapper starting to map UML Class Diagram to model jast for "
                            + model.getName() + " model" );

            // map UML model to JAST tree
            JastCompilationPackage compilationUnits = new JastCompilationPackage();
            uml2ast( model, compilationUnits );
            

            if (compilationUnits != null) {
                // write out the JAST tree
                bb.writeData( "JAST Tree", compilationUnits );

                // write out DEBUGGING data
                // bb.writeData( "JAST->UML Mappings", mappings );
            }

            data.discard();
        } catch (Exception e) {
            // e.printStackTrace ( );
            _pipeline.getLogger().severe(
                    e.getMessage()
                            + "\nSTOPPING ClassDiagramToJastMapper Plugin" );
            throw new UmlvmPluginException( "ClassDiagramToJastMapper Plugin, "
                    + e );
        }
    }


    /**
     * map UML2 model to abstract syntax tree
     * 
     * @author Adam
     * 
     * @param model
     *            UML2 model
     * @param compilationUnits
     *            compilation units produced by previous mapping module, or null
     * 
     * @return collection of compilation units produced/updated
     */
    public void uml2ast( Model model, JastCompilationPackage units )
        throws MapperException {
        
        if( units == null ) {
            return;
        }
        
        units.setName( model.getName() );
        
        EList list = model.getOwnedTypes();
        Iterator iter = list.iterator();

        ASTParser parser = ASTParser.newParser( AST.JLS2 );

        // iterate over direct elements of the model
        while (iter.hasNext()) {
            org.eclipse.uml2.Type el = (org.eclipse.uml2.Type) iter.next();

            // create a new compilation unit for each class or interface
            // ignore other subclasses of Class
            if ((el instanceof Class || el instanceof Interface)
                    && !(el instanceof Interaction)
                    && !(el instanceof Activity)
                    && !(el instanceof AssociationClass)
                    && !(el instanceof Behavior) && !(el instanceof Component)
                    && !(el instanceof Device)
                    && !(el instanceof ExecutionEnvironment)
                    && !(el instanceof Node) && !(el instanceof StateMachine)
                    && !(el instanceof ProtocolStateMachine)
                    && !(el instanceof Stereotype)) {
                parser.setSource( new String().toCharArray() );

                CompilationUnit cu = (CompilationUnit) parser.createAST( null );
                cu.recordModifications();

                // update cur compilation unit
                curUnit = cu;

                if (el instanceof Class) {
                    curUnit.types().add( caseClass( (Class) el ) );
                } else if (el instanceof Interface) {
                    curUnit.types().add( caseInterface( (Interface) el ) );
                }

                // add compilation unit to collection
                units.add( cu );
            }
        }
    }

    /**
     * @author Adam
     * 
     * 
     */
    public Object caseClass( Class umlClass ) throws MapperException {
        String className = umlClass.getName();

        AST ast = curUnit.getAST();

        TypeDeclaration classDecl = ast.newTypeDeclaration();

        // extract name
        try {
            classDecl.setName( ast.newSimpleName( className ) );
        } catch (IllegalArgumentException e) {
            throw new MapperException( "Illegal class/interface identifier: "
                    + className );
        }

        // check if <<javainterface>>
        if (UML2Util.isAppliedStereotype( umlClass, Profile.EJB.JavaInterface ) != null) {
            classDecl.setInterface( true );
            classDecl.setModifiers( Modifier.PUBLIC );
        } else {
            classDecl.setInterface( false );

            // set class modifiers
            classDecl.setModifiers( getClassModifiers( umlClass ) );

            // check if implements any interfaces and map them
            EList implementations = umlClass.getImplementations();

            for (int i = 0; i < implementations.size(); i++) {
                Implementation classImplements = (Implementation) implementations
                        .get( i );

                Name interfaceImplementedName = (Name) caseImplementation( classImplements );
                classDecl.superInterfaces().add( interfaceImplementedName );
            }
        }

        // check superclass, should be only one as by profile
        EList generalizations = umlClass.getGeneralizations();

        if (generalizations.size() > 0) {
            // get only first one, shoulnd't be more
            Generalization classExtends = (Generalization) generalizations
                    .get( 0 );
            Name classExtendsName = (Name) caseGeneralization( classExtends );
            classDecl.setSuperclass( classExtendsName );
        }

        // process attributes
        EList attrList = umlClass.getOwnedAttributes();

        for (int i = 0; i < attrList.size(); i++) {
            Property umlAttr = (Property) attrList.get( i );
            FieldDeclaration fieldDecl = (FieldDeclaration) caseProperty( umlAttr );
            classDecl.bodyDeclarations().add( fieldDecl );
        }

        // process operations
        EList operList = umlClass.getOwnedOperations();

        for (int i = 0; i < operList.size(); i++) {
            Operation umlOper = (Operation) operList.get( i );
            MethodDeclaration methodDecl = (MethodDeclaration) caseOperation( umlOper );
            classDecl.bodyDeclarations().add( methodDecl );
        }

        // record mapping made
        mappings.add( classDecl, umlClass );

        return classDecl;
    }

    /**
     * 
     * @author Adam
     * 
     * 
     * @param umlProp
     * @return JAST FieldDeclaration corresponding to this UML Property
     */
    public Object caseProperty( Property umlProp ) throws MapperException {
        AST ast = curUnit.getAST();
        VariableDeclarationFragment fieldFrag = ast
                .newVariableDeclarationFragment();

        // field name
        try {
            fieldFrag.setName( ast.newSimpleName( umlProp.getName() ) );
        } catch (IllegalArgumentException e) {
            throw new MapperException( umlProp, "Illegal Field Name" );
        }

        // initializer TODO
        // TODO inits for member declaration should be added to profile
        // as DefaultValueOpaqueExpression
        // visibility and type -- ignore groupings in source
        FieldDeclaration fieldDecl = ast.newFieldDeclaration( fieldFrag );
        int modifier = getFieldModifiers( umlProp );
        fieldDecl.setModifiers( modifier );

        // type
        String typeStr = umlProp.getType().getName();

        // check if has JavaDimensions
        int dimensions = getTypeDimensions( umlProp );

        if (dimensions < 0) {
            _pipeline.getLogger().warning(
                    "JavaDimensions tag negative.  Using absolute value.  In Property: "
                            + umlProp + " in Class: " + umlProp.getOwner() );
            dimensions = Math.abs( dimensions );
        }

        while (dimensions-- > 0)
            typeStr += "[]";

        try {
            org.eclipse.jdt.core.dom.Type type = TypeBuilder.buildFieldType(
                    typeStr, curUnit );
            fieldDecl.setType( type );
        } catch (ModelParsingException e) {
            throw new MapperException( umlProp, e.getMessage() );
        }

        // record ast to uml2 mapping for reverse lookup
        mappings.add( fieldDecl, umlProp );

        return fieldDecl;
    }

    /**
     * map class diagram operation to a JAST method declaration with body having
     * only return statement compatibile with method's return type
     * 
     * 
     * @author Adam
     * 
     * @param umlOper
     *            uml operation to be mapped
     * @return freshly created ASTNode for Java MethodDeclaration
     */
    public Object caseOperation( Operation umlOper ) throws MapperException {
        AST ast = curUnit.getAST();
        MethodDeclaration methodDecl = ast.newMethodDeclaration();

        // name
        String methodNameStr = umlOper.getName();

        try {
            methodDecl.setName( ast.newSimpleName( methodNameStr ) );
        } catch (IllegalArgumentException e) {
            throw new MapperException( umlOper, (Class) umlOper.getOwner(),
                    "Illegal Operation Name" );
        }

        // set constructor
        // owner for sure is Class or Interface so safe cast
        String className = ((Classifier) umlOper.getOwner()).getName();

        if (className.equals( methodNameStr )) {
            methodDecl.setConstructor( true );
        } else {
            methodDecl.setConstructor( false );
        }

        // set modifiers, visibility
        int methodModifiers = getMethodModifiers( umlOper );
        methodDecl.setModifiers( methodModifiers );

        // set stub bodies here, add return type later when type resolved
        // dont set bodies for abstract methods and interfaces
        ReturnStatement retStatement = null;
        Block stubBlock = ast.newBlock(); // method block with the return st.

        // add prepared later return statement to body and add the body
        // only if not interface and not abstract method
        Classifier parent = (Classifier) umlOper.getOwner();

        if (!(parent instanceof Interface || umlOper.isAbstract())) {
            // add return to body if not a constructor
            if (!methodDecl.isConstructor()) {
                retStatement = ast.newReturnStatement();
                stubBlock.statements().add( retStatement );
            }

            // set body if not abstract method or interface
            methodDecl.setBody( stubBlock );
        }

        // set types (return and formal)
        EList params = umlOper.getParameters();

        boolean gotReturn = false;

        // map all parameters
        for (int i = 0; i < params.size(); i++) {
            Parameter umlParam = (Parameter) params.get( i );
            String umlParamName = umlParam.getName();

            // return parameter if name OR direction attr equals return
            // make sure it's processed only once (in case of >1 return
            // parameters in model)
            if (!gotReturn
                    && (!methodDecl.isConstructor())
                    && (umlParamName.equals( "return" ) || (umlParam
                            .getDirection().getValue() == ParameterDirectionKind.RETURN))) {
                // this is a return type
                gotReturn = true; // do not enter here again

                org.eclipse.uml2.Type retType = (org.eclipse.uml2.Type) umlParam
                        .getType();

                String umlRetTypeName = null;

                // in case if not defined, it's void
                if (retType != null) {
                    umlRetTypeName = retType.getName();
                }

                // build jast type and body stub
                Type jRetType = null;
                Expression retExpression = null; // expression for return,
                                                    // nothing in case of void

                // if no type value set, then void
                if ((umlRetTypeName == null) || umlRetTypeName.equals( "" )) {
                    jRetType = ast.newPrimitiveType( PrimitiveType.VOID );

                    // nothing to add to return statement
                } else { // PrimitiveType, SimpleType or ArrayType

                    // check if has JavaDimensions
                    int dimensions = getTypeDimensions( umlParam );

                    while (dimensions-- > 0)
                        umlRetTypeName += "[]";

                    // TODO check if should use setExtraDimensions
                    // parse the ret type
                    try {
                        jRetType = TypeBuilder.buildMethodRetType(
                                umlRetTypeName, curUnit );
                    } catch (ModelParsingException e) {
                        throw new MapperException( retType, e.getMessage() );
                    }

                    // set proper return statement
                    if (jRetType instanceof ArrayType
                            || jRetType instanceof SimpleType
                            || jRetType instanceof QualifiedType) {
                        // expression: return null;
                        retExpression = ast.newNullLiteral();
                    } else if (jRetType instanceof PrimitiveType) {
                        PrimitiveType primitiv = (PrimitiveType) jRetType;

                        if (primitiv.getPrimitiveTypeCode() == PrimitiveType.CHAR) {
                            // expression: return '0';
                            retExpression = ast.newCharacterLiteral();
                            ((CharacterLiteral) retExpression)
                                    .setCharValue( '0' );
                        } else if (primitiv.getPrimitiveTypeCode() == PrimitiveType.BOOLEAN) {
                            // expression: return true;
                            retExpression = ast.newBooleanLiteral( true );
                        } else {
                            // expression: return 0;
                            retExpression = ast.newNumberLiteral( "0" );
                        }
                    }

                    // add produced expression to the return statement
                    if (!(parent instanceof Interface || umlOper.isAbstract())) {
                        retStatement.setExpression( retExpression );
                    }
                }

                // set the return type
                methodDecl.setReturnType( jRetType );
            }

            else // this is formal parameter, add to the list
            {
                SingleVariableDeclaration decl = ast
                        .newSingleVariableDeclaration();

                // name
                try {
                    decl.setName( ast.newSimpleName( umlParamName ) );
                } catch (IllegalArgumentException e) {
                    throw new MapperException( umlParam, (Class) umlOper
                            .getOwner(), "Illegal Parameter Name" );
                }

                // type
                org.eclipse.uml2.Type umlParamType = (org.eclipse.uml2.Type) umlParam
                        .getType();

                String umlParamTypeName = null;

                // in case type not given: defaults are set to int and compiler
                // will complain
                if (umlParamType != null) {
                    umlParamTypeName = umlParamType.getName();

                    // check if has JavaDimensions
                    int dimensions = getTypeDimensions( umlParam );

                    while (dimensions-- > 0)
                        umlParamTypeName += "[]";

                    try {
                        // TODO check if should use setExtraDimensions
                        Type jType = TypeBuilder.buildMethodParamType(
                                umlParamTypeName, curUnit );

                        decl.setType( jType );
                    } catch (ModelParsingException e) {
                        throw new MapperException( umlParamType, e.getMessage() );
                    }
                }

                // add declaration to parameter list
                methodDecl.parameters().add( decl );
            }
        }

        // record ast to uml2 mapping for reverse lookup
        mappings.add( methodDecl, umlOper );

        return methodDecl;
    }

    /**
     * 
     * @author Adam
     * 
     */
    public Object caseInterface( Interface umlInterface )
            throws MapperException {
        String interfaceName = umlInterface.getName();
        AST ast = curUnit.getAST();

        TypeDeclaration interfaceDecl = ast.newTypeDeclaration();
        interfaceDecl.setInterface( true );
        interfaceDecl.setModifiers( Modifier.PUBLIC );

        try {
            interfaceDecl.setName( ast.newSimpleName( interfaceName ) );
        } catch (IllegalArgumentException e) {
            throw new MapperException( umlInterface, "Illegal Interface Name" );
        }

        // process operations
        EList operList = umlInterface.getOwnedOperations();

        for (int i = 0; i < operList.size(); i++) {
            Operation umlOper = (Operation) operList.get( i );
            MethodDeclaration methodDecl = (MethodDeclaration) caseOperation( umlOper );
            interfaceDecl.bodyDeclarations().add( methodDecl );
        }

        // record ast to uml2 mapping for reverse lookup
        mappings.add( interfaceDecl, umlInterface );

        return interfaceDecl;
    }

    /**
     * @author Adam
     * 
     * 
     */
    public Object caseImplementation( Implementation implementation ) {
        Interface implementedInterface = implementation.getContract();
        String interfaceNameStr = implementedInterface.getName();

        Name interfaceName = curUnit.getAST().newSimpleName( interfaceNameStr );

        return interfaceName;
    }

    /**
     * @author Adam
     */
    public Object caseGeneralization( Generalization generalization ) {
        String superClassNameStr = generalization.getGeneral().getName();
        Name superClassName = curUnit.getAST()
                .newSimpleName( superClassNameStr );

        return superClassName;
    }

    // get JAST compatibile class decl. modifiers translated from UML modifiers
    public static int getClassModifiers( Class umlClass ) {
        int retModifier = 0;

        Object staticTag = UML2Util.isAppliedTag( umlClass, "JavaStatic" );
        int isStatic = (String.valueOf( staticTag ).equals( "true" )) ? Modifier.STATIC
                : 0;

        Object strictfpTag = UML2Util.isAppliedTag( umlClass, "JavaStrictfp" );
        int isStrictfp = (String.valueOf( strictfpTag ).equals( "true" )) ? Modifier.STRICTFP
                : 0;

        int isAbstract = (umlClass.isAbstract()) ? Modifier.ABSTRACT : 0;

        VisibilityKind umlVisibility = umlClass.getVisibility();

        switch (umlVisibility.getValue()) {
        case VisibilityKind.PRIVATE:
            retModifier = (Modifier.PRIVATE | isStatic | isStrictfp | isAbstract);

            break;

        case VisibilityKind.PUBLIC:
            retModifier = (Modifier.PUBLIC | isStatic | isStrictfp | isAbstract);

            break;

        case VisibilityKind.PROTECTED:
            retModifier = (Modifier.PROTECTED | isStatic | isStrictfp | isAbstract);

            break;

        default: // no visibility - defaults to package
            retModifier = (isStatic | isStrictfp | isAbstract);
        }

        return retModifier;
    }

    // get JAST compatibile field decl. modifiers translated from UML modifiers
    public static int getFieldModifiers( Property umlProp ) {
        int retModifier = 0;

        int isStatic = (umlProp.isStatic()) ? Modifier.STATIC : 0;

        // resolve JavaFinal tag (boolean)
        Object finalTag = UML2Util.isAppliedTag( umlProp, "JavaFinal" );

        int isFinal = (String.valueOf( finalTag ).equals( "true" )) ? Modifier.FINAL
                : 0;

        VisibilityKind umlVisibility = umlProp.getVisibility();

        switch (umlVisibility.getValue()) {
        case VisibilityKind.PRIVATE:
            retModifier = (Modifier.PRIVATE | isStatic | isFinal);

            break;

        case VisibilityKind.PUBLIC:
            retModifier = (Modifier.PUBLIC | isStatic | isFinal);

            break;

        case VisibilityKind.PROTECTED:
            retModifier = (Modifier.PROTECTED | isStatic | isFinal);

            break;

        default: // no visibility - defaults to package
            retModifier = (isStatic | isFinal);
        }

        return retModifier;
    }

    // get JAST compatibile methods modifiers translated from UML modifiers
    public static int getMethodModifiers( Operation umlOper ) {
        int retModifier = 0;

        int isStatic = (umlOper.isStatic()) ? Modifier.STATIC : 0;
        int isAbstract = (umlOper.isAbstract()) ? Modifier.ABSTRACT : 0;

        Object nativeTag = UML2Util.isAppliedTag( umlOper, "JavaNative" );

        int isNative = (String.valueOf( nativeTag ).equals( "true" )) ? Modifier.NATIVE
                : 0;

        VisibilityKind umlVisibility = umlOper.getVisibility();

        switch (umlVisibility.getValue()) {
        case VisibilityKind.PRIVATE:
            retModifier = (Modifier.PRIVATE | isStatic | isAbstract | isNative);

            break;

        case VisibilityKind.PUBLIC:
            retModifier = (Modifier.PUBLIC | isStatic | isAbstract | isNative);

            break;

        case VisibilityKind.PROTECTED:
            retModifier = (Modifier.PROTECTED | isStatic | isAbstract | isNative);

            break;

        default:
            retModifier = (isStatic | isAbstract | isNative);
        }

        return retModifier;
    }

    /**
     * return dimensions integer defined in JavaDimensions tag
     * 
     * @param el
     *            element to which JavaDimensions tag is applied
     * @return integer repr. java array dimensions
     */
    public static int getTypeDimensions( NamedElement el ) {
        int dimensionRet = 0;

        if (!(el instanceof Property || el instanceof Parameter)) {
            return 0;
        }

        // check if has JavaDimensions TAG
        Object dimTag = UML2Util.isAppliedTag( el, "JavaDimensions" );

        if (dimTag != null) {
            Integer dimTagInt = Integer.valueOf( String.valueOf( dimTag ) );
            dimensionRet = dimTagInt.intValue();
        }

        return dimensionRet;
    }
}
