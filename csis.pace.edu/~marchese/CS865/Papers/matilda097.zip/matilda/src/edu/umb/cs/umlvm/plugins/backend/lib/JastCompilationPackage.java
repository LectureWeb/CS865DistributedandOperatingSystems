/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.backend.lib;

import java.io.Serializable;
import java.util.*;

import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import edu.umb.cs.umlvm.core.util.JDTUtil;

/**
 * @author Adam
 * 
 * each object contained in JastCompilationPackage represents one class file
 * 
 * 
 */
public class JastCompilationPackage implements Serializable {

    // collection of CompilationUnits
    // CompilationUnit is not serializable
    transient private Map<String, CompilationUnit> _units;

    // name of the package
    private String name = "";

    // CompilationUnits is not serializable
    // This array is used for serialize the data of CompilationUnits
    private Map<String, String> _source;

    public JastCompilationPackage() {
        _units = new HashMap<String, CompilationUnit>();
        _source = new HashMap<String, String>();
    }

    public void add( CompilationUnit unit ) {

        // Add an unit to a map
        TypeDeclaration type = (TypeDeclaration) unit.types().get( 0 );
        String className = type.getName().getIdentifier();
        _units.put( className, unit );

    }

    public String getName() {
        return this.name;
    }

    public void setName( String name ) {
        this.name = name;
    }

    public Collection<String> getClassNames() {
      if( _units == null ){
        return _source.keySet();
      }
      else{
        return _units.keySet();
      }
    }

    /**
     * retrieve compilation unit (first found - should be only one) with a class
     * of a given name or null if no such class inner classes not supported
     * 
     * @param className
     *            name of class to be retrieved
     * @return CompilationUnit for the class
     */
    public CompilationUnit getUnit( String className ) {

        CompilationUnit unit = null;

        // instances of CompilationUnit are available
        if (_units != null) {
            unit = _units.get( className );
            if (unit != null) {
                return unit;
            }
        } else {
            _units = new HashMap<String, CompilationUnit>();
        }

        // When this object is deserialized, instances of
        // CompilationUnit are not available.
        // Source code is available because it can be serialized
        String src = _source.get( className );
        if (src == null) {
            return null;
        }

        unit = JDTUtil.Source2CompilationUnit( src );
        _units.put( className, unit );

        return unit;
    }
    
    public int getSize() {
        int size = 0;
        Iterator it = _units.values().iterator();
        while (it.hasNext()) {
            size += it.next().toString().length();
        }
        return size;
    }
    
    public void serialize() {
        // Transforms an unit to source code, and put it to an array

        Iterator<String> it = _units.keySet().iterator();
        while (it.hasNext()) {
            String className = it.next();
            CompilationUnit unit = getUnit( className );
            
            String src = JDTUtil.CompilationUnit2Source( unit );
            _source.put( className, src );
        }
    }

    /**
     * 
     * for debugging only, return String representation of the package showing
     * current source code of all units
     * 
     * @author Adam
     * 
     * @ret source code representation of all compilation units
     */
    public String toString() {
        Iterator iter = _units.values().iterator();
        StringBuffer sbuf = new StringBuffer();

        sbuf.append( "\n\nJAST Source Code Representation\n\nFor DEBUGGING Purposes only\n" );

        sbuf.append( "\nCompilation Unit Package: " + getName() + "\n" );

        while (iter.hasNext()) {
            CompilationUnit unit = (CompilationUnit) iter.next();

            sbuf.append( "\n\n//************ CompilationUnit *************\n" );

            String source = JDTUtil.CompilationUnit2Source( unit );

            sbuf.append( source );
        }

        return sbuf.toString();
    }
}
