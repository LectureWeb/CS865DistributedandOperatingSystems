/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Adam M
 * 
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.backend;

import edu.umb.cs.umlvm.plugins.backend.lib.JastCompilationPackage;
import edu.umb.cs.umlvm.plugins.backend.lib.MapperException;

import org.eclipse.uml2.Model;

/**
 * @author Adam
 * 
 */
public interface UML2ASTMapper {
    /**
     * map UML2 model to abstract syntax tree
     * 
     * 
     * @param model
     *            UML2 model
     * @param compilationUnits
     *            compilation units produced by previous mapping module, or null
     * 
     * @return collection of compilation units produced/updated
     */
    public void uml2ast( Model model, JastCompilationPackage compilationUnits )
        throws MapperException;
}
