	/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.BlackboardImpl;
import edu.umb.cs.umlvm.core.blackboard.BlackboardProxy;
import edu.umb.cs.umlvm.core.config.Config;
import edu.umb.cs.umlvm.util.Footprint;

public class VirtualMachine {
    public static void main( String[] args ) {
        // initialize commandline options
        Options options = initOptions();

        // parse commandline options
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        try {
            cmd = parser.parse( options, args );
        } catch (ParseException e) {
            HelpFormatter help = new HelpFormatter();
            help.printHelp( "VirtualMachine", options, true );
            return;
        }

        String bbName = null;
        if (cmd.hasOption( "b" )) {
            bbName = cmd.getOptionValue( "b" );
        }

        String bbHost = "localhost";
        if (cmd.hasOption( "h" )) {
            bbName = cmd.getOptionValue( "h" );
        }

        String configFileName = cmd.getOptionValue( "c" );
        Config config = new Config();
        config.loadConfig( configFileName );

        Boolean extension = false;
        if (cmd.hasOption( "e" )) {
            extension = true;
        }

        boolean gui = false;
        if (cmd.hasOption( "g" )) {
            gui = true;
        }

        int numberOfExecution = 1;
        if (cmd.hasOption( "n" )) {
            numberOfExecution = Integer.parseInt( cmd.getOptionValue( "n" ) );
        }

        // start virtual machine
        try {
            Console console;
            if (gui) {
                console = new Console();
            }

            Blackboard bb = null;

            if (bbName == null) {
                bb = new BlackboardImpl();
            } else {
                bb = new BlackboardProxy( bbName, bbHost, config );
            }
            bb.initialize();

            if (!extension) // start pipelibe only if this instance is not a
                            // pipeline extention
            {
                Pipeline pipeline;
                for (int i = 0; i < numberOfExecution; i++) {
                    pipeline = new Pipeline( config, bb );
                    pipeline.initialize();
                    pipeline.start();
                    
                    pipeline = null;
                    Footprint.getUsedMemory( true );
                }
            }
        } catch (Exception e) {
            System.out.println( e );
        }
    }

    private static Options initOptions() {

        Options options = new Options();

        Option blackboardOp = OptionBuilder.hasArg( true ).withArgName(
                "name of blackboard" ).isRequired( false ).withDescription(
                "name of a blackboard" ).withLongOpt( "blackboard" ).create(
                "b" );

        Option blackboardHostOp = OptionBuilder.hasArg( true ).withArgName(
              "blackboard host" ).isRequired( false ).withDescription(
              "blackboard host (default 'localhost')" ).withLongOpt( "host" ).create(
              "h" );

        Option configOp = OptionBuilder.hasArg( true ).withArgName( "filename" )
                .isRequired( true ).withDescription( "config file" )
                .withLongOpt( "config" ).create( "c" );

        Option extensionOp = OptionBuilder.hasArg( false ).isRequired( false )
                .withDescription( "extension" ).withLongOpt( "extension" )
                .create( "e" );

        Option guiOp = OptionBuilder.hasArg( false ).isRequired( false )
                .withDescription( "GUI" ).withLongOpt( "gui" ).create( "g" );

        Option measurementOp = OptionBuilder.hasArg( true ).withArgName(
                "number of execution" ).isRequired( false ).withDescription(
                "number of execution" ).withLongOpt( "number" ).create(
                "n" );

        options.addOption( blackboardOp );
        options.addOption( blackboardHostOp );
        options.addOption( configOp );
        options.addOption( extensionOp );
        options.addOption( guiOp );
        options.addOption( measurementOp );

        return options;
    }

}
