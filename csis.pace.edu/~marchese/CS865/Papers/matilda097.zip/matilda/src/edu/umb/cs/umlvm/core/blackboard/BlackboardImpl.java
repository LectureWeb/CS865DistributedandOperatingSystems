/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core.blackboard;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.cli.*;

import edu.umb.cs.umlvm.core.blackboard.data.Data;

public class BlackboardImpl extends UnicastRemoteObject implements Blackboard {

    private Map<String, Object> objectstore = null;


    public BlackboardImpl() throws RemoteException {
        initialize();
    }

    public void initialize(){
        if (objectstore == null)
            objectstore = new HashMap<String, Object>();
    }

    public void writeData( String DataID, Object object ){
        objectstore.put( DataID, object );
    }

    public Data readData( String DataID )
            throws DataNotFoundException {
        if (!objectstore.containsKey( DataID ))
            throw new DataNotFoundException( "Blackboard: Missing Data" );

        return new Data( objectstore.get( DataID ) );
    }

    public static void main( String[] args ) {

        // initialize commandline options
        Options options = initOptions();

        // parse commandline options
        CommandLineParser parser = new PosixParser();
        CommandLine cmd = null;
        try {
            cmd = parser.parse( options, args );
        } catch (ParseException e) {
            HelpFormatter help = new HelpFormatter();
            help.printHelp( "BlackboardImpl", options, true );
            return;
        }

        String bbName = null;
        if (cmd.hasOption( "b" )) {
            bbName = cmd.getOptionValue( "b" );
        }

        try {
            if (System.getSecurityManager() == null) {
                System.setSecurityManager( new RMISecurityManager() );
            }

            Naming.rebind( bbName, new BlackboardImpl() );
            System.out.println( "Blackboard Started @ " + bbName );
        } catch (Exception e) {
            System.err.println( "Blackboard exception: " + e.getMessage() );
            e.printStackTrace();
        }
    }

    private static Options initOptions() {

        Options options = new Options();

        Option blackboardOp = OptionBuilder.hasArg( true ).withArgName(
                "name of blackboard" ).isRequired( true ).withDescription(
                "name of a blackboard" ).withLongOpt( "blackboard" ).create(
                "b" );

        options.addOption( blackboardOp );

        return options;
    }
}
