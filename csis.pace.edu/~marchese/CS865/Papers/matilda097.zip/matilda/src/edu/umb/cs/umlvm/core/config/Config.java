/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

/**
 * @author EMMadhuBabu
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

package edu.umb.cs.umlvm.core.config;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class Config {

    Document PipelineConfig;

    int currentPlugin;

    public void loadConfig( String FileName ) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setValidating( false );
            PipelineConfig = factory.newDocumentBuilder().parse(
                    new File( FileName ) );
            currentPlugin = 0;
        } catch (ParserConfigurationException e) {

        } catch (IOException e) {

        } catch (SAXException e) {

        }
    }

    public void resetIterator() {
        currentPlugin = 0;
    }

    public String getNextPluginClass() {
        NodeList pluginNodes = PipelineConfig.getElementsByTagName( "plugin" );
        int numberOfPlugins = pluginNodes.getLength();
        for (int i = 0; i < numberOfPlugins; i++) {
            Element pluginTag = (Element) pluginNodes.item( i );
            Element pluginNameTag = (Element) pluginTag.getElementsByTagName(
                    "plugin-class" ).item( 0 );
            String className = ((Text) pluginNameTag.getFirstChild()).getData()
                    .trim();
            if (currentPlugin == i) {
                currentPlugin++;
                return className;
            }
        }
        return null;
    }

    public String getParam( String PluginName, String param ) {
        NodeList pluginNodes = PipelineConfig.getElementsByTagName( "plugin" );
        int numberOfPlugins = pluginNodes.getLength();
        for (int i = 0; i < numberOfPlugins; i++) {
            Element pluginTag = (Element) pluginNodes.item( i );
            Element pluginNameTag = (Element) pluginTag.getElementsByTagName(
                    "plugin-class" ).item( 0 );
            String className = ((Text) pluginNameTag.getFirstChild()).getData()
                    .trim();
            if (className.equalsIgnoreCase( PluginName )) {
                NodeList pluginInputNodes = pluginTag
                        .getElementsByTagName( "plugin-input" );
                int numberOfInputs = pluginInputNodes.getLength();
                for (int j = 0; j < numberOfInputs; j++) {
                    Element pluginInputTag = (Element) pluginInputNodes
                            .item( j );
                    Element pluginParamTag = (Element) pluginInputTag
                            .getElementsByTagName( "param-name" ).item( 0 );
                    String paramName = ((Text) pluginParamTag.getFirstChild())
                            .getData().trim();
                    if (paramName.equalsIgnoreCase( param )) {
                        Element pluginParamValue = (Element) pluginInputTag
                                .getElementsByTagName( "param-value" ).item( 0 );
                        String paramValue = ((Text) pluginParamValue
                                .getFirstChild()).getData().trim();
                        return paramValue;
                    }
                }

            }
        }
        return null;
    }

    
    public String getParam( String param ) {
        NodeList paramNodes = PipelineConfig.getElementsByTagName( "param" );
        for (int i = 0; i < paramNodes.getLength(); i++) {
          Element paramTag = (Element)paramNodes.item( i );
          Element nameTag = (Element)paramTag.getElementsByTagName( "name" ).item( 0 );
          String name = ((Text)nameTag.getFirstChild()).getData().trim();
          if( name.equals( param ) ){
            Element valueTag = (Element)paramTag.getElementsByTagName( "value" ).item( 0 );
            String value = ((Text)valueTag.getFirstChild()).getData().trim();          
            return value;
          }
        }
        return null;
    }
    
    public String getLogFileName() {
        NodeList logfileNodes = PipelineConfig.getElementsByTagName( "logfile" );
        int numberOfNodes = logfileNodes.getLength();
        for (int i = 0; i < numberOfNodes; i++) {
            Element logTag = (Element) logfileNodes.item( i );
            String fileName = ((Text) logTag.getFirstChild()).getData().trim();
            if (fileName != null) {
                return fileName;
            }
        }
        return null;
    }

    public Level getLogLevel() {
        NodeList logLevelNodes = PipelineConfig
                .getElementsByTagName( "loglevel" );
        int numberOfNodes = logLevelNodes.getLength();
        for (int i = 0; i < numberOfNodes; i++) {
            Element logTag = (Element) logLevelNodes.item( i );
            String fileName = ((Text) logTag.getFirstChild()).getData().trim();

            switch (Integer.parseInt( fileName )) {
            case 0:
                return Level.ALL;
            case 1:
                return Level.INFO;
            case 2:
                return Level.WARNING;
            case 3:
                return Level.SEVERE;
            case 9:
                return Level.OFF;
            default:
                return Level.ALL;
            }

        }
        return Level.ALL;
    }

}
