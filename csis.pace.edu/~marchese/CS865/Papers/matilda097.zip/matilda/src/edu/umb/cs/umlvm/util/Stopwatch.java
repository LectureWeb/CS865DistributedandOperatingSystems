/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on 2005/09/30
 * Contributors: Hiroshi Wada
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.util;

import java.io.*;

/**
 * This class is creates a stopwatch object. Used for analyzing functions
 * performance time.
 * 
 * @author Jun Suzuki (jsuzuki@ics.uci.edu)
 * @author Mike Le (mvle@uci.edu)
 */
public class Stopwatch implements Serializable {
	private long startTime = 0;
	private long stopTime = 0;
	private long startLapTime = 0;

	/**
	 * Flag to discern if function being tested is still running, False if stop,
	 * True if running
	 */
	private boolean running = false;

	/**
	 * Starts the stopwatch by initializing the startTime to the current time on
	 * the machine. Function begins to run so running flag is set to true.
	 */
	public void start() {
		startTime = System.nanoTime();
		startLapTime = startTime;
		running = true;
	}

	/**
	 * Stops the stopwatch by storing the current system time into the stopTime
	 * variable. Function stops so running flag is set to false.
	 */
	public void stop() {
		stopTime = System.nanoTime();
		running = false;
	}

	/**
	 * Gets the time elapsed since the startTime of the function till this
	 * function is called.
	 * 
	 * @return a double containing the time elapsed in milli seconds.
	 *         <UL>
	 *         <LI>If the watch has never been started then zero seconds are
	 *         returned.
	 *         <LI>If the function is still running, then return current time
	 *         subtract the startTime.
	 *         <LI>If the function has stopped, then return the difference of
	 *         the stopTime and the startTime.
	 *         </UL>
	 */
	public long getElapsedTime() {
		if (startTime == 0)
			return 0;
		else if (running)
			return System.nanoTime() - startTime;
		else
			return stopTime - startTime;
	}

	public long getLapTime() {

		if (startTime == 0)
			return 0;
		if (running) {
			long current = System.nanoTime();
			long result = current - startLapTime;
			startLapTime = current;

			return result;
		} else
			return stopTime - startLapTime;
	}

	/**
	 * Resets the stopwatch variables to their initial values.
	 * 
	 * @return the Stopwatch with all the initial settings.
	 */
	public Stopwatch reset() {
		startTime = 0;
		stopTime = 0;
		startLapTime = 0;
		running = false;
		return this;
	}

	/**
	 * Used to test this class. Starts the stopwatch then sleep for 1000 milli
	 * seconds and then stop the stopwatch and print out the elapsed time to the
	 * console.
	 */
	/*
	 * public static void main(String[] args) {
	 * edu.uci.ics.bionet.util.analysis.Stopwatch stopwatch = new
	 * edu.uci.ics.bionet.util.analysis.Stopwatch(); stopwatch.start(); try {
	 * Thread.sleep(1000); } catch(Exception ex) {} stopwatch.stop();
	 * System.out.println(stopwatch.getElapsedTime()); }
	 */
}