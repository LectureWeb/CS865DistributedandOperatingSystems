/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core.util;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

public class JDTUtil {

    public static String CompilationUnit2Source( CompilationUnit unit ) {
        if (unit == null) {
            return "";
        }
        
        return unit.toString();

        // The following code is for Eclipse 3.0
        /*

        // unit.recordModifications();
        Document doc = new Document();

        TextEdit edits = unit.rewrite( doc, null );

        try {
            UndoEdit undo = edits.apply( doc );
        } catch (BadLocationException e) {
            System.out.println( e.toString() );
        }

        return doc.get();
        */
    }

    public static CompilationUnit Source2CompilationUnit( String source ) {
        ASTParser parser = ASTParser.newParser( AST.JLS2 );
        // parser.setKind( ASTParser.K_COMPILATION_UNIT );
        parser.setSource( source.toCharArray() );
        CompilationUnit unit = (CompilationUnit) parser.createAST( null );
        // unit.recordModifications();
        return unit;
    }

}
