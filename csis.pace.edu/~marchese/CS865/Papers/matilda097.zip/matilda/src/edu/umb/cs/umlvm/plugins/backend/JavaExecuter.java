/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Adam M
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.backend;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.Class;
import org.eclipse.uml2.Element;
import org.eclipse.uml2.Interaction;
import org.eclipse.uml2.Interface;
import org.eclipse.uml2.Model;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.core.util.UML2Util;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.Profile;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;

/**
 * @author Adam
 * 
 * executes byte code using JVM java command redirects output to the UMLVM
 * console deletes cache class files
 * 
 */
public class JavaExecuter implements Plugin {
    protected Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
    }

    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            // get class files repr.
            Data classData = bb.readData( "class files" );

            if (classData == null) {
                throw new DataNotFoundException(
                        "Byte-code files not found or invalid object type.  Expecting File []" );
            }

            File[] classFiles = (File[]) classData.getObject();

            // get UML model to find executable class, throw if exec not found
            Data modelData = bb.readData( "UMLTree" );

            if (modelData == null) {
                throw new DataNotFoundException(
                        "UML2 model not found or invalid object type.  Expecting org.eclipse.uml2.Model" );
            }

            Model model = (Model) modelData.getObject();
            String execClassName = getExecClassName( model );
            modelData.discard();

            // get exec arguments
            String argsStr =
                _pipeline
                    .getConfig()
                    .getParam( this.getClass().getName(), "arguments" );

            if (execClassName == null) {
                _pipeline.getLogger().info(
                        "No <<UMLVMExecutable>> class found, nothing to execute" );
            } else {
                _pipeline.getLogger().info(
                        "<<UMLVMExecutable>> " + execClassName + " class found, executing" );
                executeBytecode( classFiles, execClassName, argsStr );

                // cleanup
                deleteFiles( classFiles );
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new UmlvmPluginException( "JastExecuter Plugin" );
        }
    }

    public void executeBytecode( File[] classFiles, String className, String args ) {
        // get directory of exec class
        String match = className + ".class";
        File workingDir = null;

        for (int i = 0; i < classFiles.length; i++) {
            if (classFiles[i].getName().equals( match )) {
                workingDir = new File( classFiles[i].getParentFile().getAbsolutePath() );
            }
        }

        try {
            Runtime rt = Runtime.getRuntime();

            _pipeline.getLogger().info( "execution arguments: |" + args + "|" );

            String execStr = "java " + className + " " + args;

            Process process = rt.exec( execStr, null, workingDir );

            InputStreamReader reader = new InputStreamReader( process.getInputStream() );

            BufferedReader buf_reader = new BufferedReader( reader );
            String line = null;
            // System.out.println ( "\n******** UMLVM model exec output START
            // ********" );

            while ((line = buf_reader.readLine()) != null) {
                // System.out.println ( line );
            }

            // System.out.println (
            // "******** UMLVM model exec output FINISH *******\n" );
        } catch (IOException e) {
            System.out.println( e );
        } catch (Exception e) {
            System.out.println( e + "\ncheck if java is in your PATH" );
        }
    }

    // return name of first found class with <<UMLVMexecutable>>
    // or null
    private String getExecClassName( Model model ) {
        EList typeList = model.getOwnedTypes();
        Iterator iter = typeList.iterator();

        // iterate over direct elements of the model
        while (iter.hasNext()) {
            org.eclipse.uml2.Type el = (org.eclipse.uml2.Type) iter.next();

            if ((el instanceof Class) && !(el instanceof Interface || el instanceof Interaction)) {
                Class cl = (Class) el;

                if (UML2Util.isAppliedStereotype( (Element) cl, Profile.EJB.UMLVMexecutable ) != null) {
                    return cl.getName();
                }
            }
        }

        return null;
    }

    // delete executed byte-code and parent dir
    private void deleteFiles( File[] files ) {
        try {
            File parent = null;

            if (files.length > 1) {
                parent = files[0].getParentFile();
            }

            for (int i = 0; i < files.length; i++) {
                files[i].delete();
            }

            if (parent != null) {
                parent.delete();
            }
        } catch (SecurityException e) {
        }
    }
}
