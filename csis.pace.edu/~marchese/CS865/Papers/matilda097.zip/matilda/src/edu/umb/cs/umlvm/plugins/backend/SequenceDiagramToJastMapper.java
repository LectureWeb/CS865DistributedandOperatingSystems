/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki, Adam M
 * 
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.plugins.backend;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jdt.core.compiler.IProblem;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.core.dom.Type;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.WhileStatement;
import org.eclipse.jface.text.Document;
import org.eclipse.uml2.CombinedFragment;
import org.eclipse.uml2.Element;
import org.eclipse.uml2.EventOccurrence;
import org.eclipse.uml2.ExecutionOccurrence;
import org.eclipse.uml2.Expression;
import org.eclipse.uml2.Interaction;
import org.eclipse.uml2.InteractionConstraint;
import org.eclipse.uml2.InteractionFragment;
import org.eclipse.uml2.InteractionOperand;
import org.eclipse.uml2.InteractionOperator;
import org.eclipse.uml2.Lifeline;
import org.eclipse.uml2.Message;
import org.eclipse.uml2.Model;
import org.eclipse.uml2.OpaqueExpression;
import org.eclipse.uml2.Stereotype;
import org.eclipse.uml2.Stop;

import edu.umb.cs.umlvm.core.Pipeline;
import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.blackboard.DataNotFoundException;
import edu.umb.cs.umlvm.core.blackboard.data.Data;
import edu.umb.cs.umlvm.core.util.UML2Util;
import edu.umb.cs.umlvm.plugins.Plugin;
import edu.umb.cs.umlvm.plugins.Profile;
import edu.umb.cs.umlvm.plugins.UmlvmPluginException;
import edu.umb.cs.umlvm.plugins.backend.lib.JastCompilationPackage;
import edu.umb.cs.umlvm.plugins.backend.lib.MapperException;
import edu.umb.cs.umlvm.plugins.backend.lib.ModelParsingException;
import edu.umb.cs.umlvm.plugins.backend.lib.TypeBuilder;
import edu.umb.cs.umlvm.plugins.backend.lib.UmlToJastMappings;

/**
 * 
 * Update pre-existing JAST with method bodies mapped from implemented UML
 * Sequence Diagrams. Parse any Java expressions.
 * 
 * 
 * @author Adam
 * 
 */
public class SequenceDiagramToJastMapper implements Plugin, UML2ASTMapper {

    // current method
    private MethodDeclaration curMethodDeclaration = null;

    // declaration being
    // updated
    private UmlToJastMappings _mappings; // UML -> JAST _mappings generated

    protected Pipeline _pipeline;

    public void initialize( Pipeline pipeline ) {
        _pipeline = pipeline;
        _mappings = new UmlToJastMappings();
    }

    /**
     * 
     * 
     * execute the plugin get data from pipeline process it update data in
     * pipeline
     */
    public void execute() throws UmlvmPluginException {
        try {
            Blackboard bb = _pipeline.getBlackboard();

            // read UML model
            Data data = bb.readData( "UMLTree" );
            Object modeldata = data.getObject();

            if (modeldata == null) {
                throw new DataNotFoundException(
                        "Model data not found or invalid object type.  Expecting org.eclipse.um2.Model" );
            }

            Model model = (Model) modeldata;

            // read JAST tree to be updated
            Data jastdata = bb.readData( "JAST Tree" );

            if (jastdata == null) {
                throw new DataNotFoundException(
                        "Jast data not found or invalid object type.  Expecting JastCompilationPackage" );
            }

            JastCompilationPackage units = (JastCompilationPackage) jastdata.getObject();


            // read JAST->UML Mappings to be updated
            /*
            Data mapdata = bb.readData( "JAST->UML Mappings" );

            if (mapdata == null) {
                throw new DataNotFoundException(
                        "Jast->Uml _mappings data not found or invalid object type.  Expecting UmlToJastMappings" );
            }

            this.mappings = (UmlToJastMappings) mapdata.getObject();

            _pipeline.getLogger().info(
                    "SequenceDiagramToJastMapper starting to map Sequence Diagrams to model jast for "
                            + model.getName() + " model" );
            */

            // map UML model - seq diagrams updating JAST tree
            uml2ast( model, units );

            if (units != null) {
                // write out the updated JAST tree
                bb.writeData( "JAST Tree", units );

                // write out the updated DEBUGGING data
                // bb.writeData( "JAST->UML Mappings", this.mappings );

                // print _mappings created
                // _mappings.print();
            }

            data.discard();
            // mapdata.discard();
        } catch (Exception e) {
            _pipeline.getLogger().severe(
                    e.getMessage() + "\nSTOPPING SequenceDiagramToJastMapper Plugin" );

            e.printStackTrace();
            throw new UmlvmPluginException( "SequenceDiagramToJastMapper Plugin" );
        }
    }

    /**
     * map UML2 model to abstract syntax tree
     * 
     * processing of Interactions belonging to Model root if match with JAST
     * compilation units and type declarations update JAST method body
     * 
     * @author Adam
     * 
     * @param model
     *            UML2 model
     * @param compilationUnits
     *            compilation units produced by previous mapping module, or null
     * 
     * @return collection of compilation units produced/updated
     */
    public void uml2ast( Model model, JastCompilationPackage units )
        throws MapperException {
        
        if( units == null ) {
            return;
        }
        
        EList list = model.getOwnedTypes();
        Iterator iter = list.iterator();

        // iterate over direct elements of the model
        while (iter.hasNext()) {
            Element el = (Element) iter.next();

            // process only Interactions
            if (el instanceof Interaction) {
                Interaction inter = (Interaction) el;

                // check if matches with type & message
                // if yes, create JAST message body and replace old one
                // return (updated) CompilationUnit
                MethodDeclaration updated = (MethodDeclaration) caseInteraction( inter, units );
            }
        }
    }

    /**
     * check if UML Interaction matches with JAST type & message if yes, create
     * JAST message body and add it to the MethodDeclaration replacing the
     * previously created body
     * 
     * @author Adam
     * 
     * @param inter
     *            Interaction containing method implementation
     * @return updated method declaration, or null if nothing was updated
     */
    public Object caseInteraction( Interaction inter, JastCompilationPackage units ) throws MapperException {
        // find if there's an existing method decl matching this interaction
        // in the compilation package
        MethodDeclaration methodDecl = getMatchingMethodDecl( inter, units );

        if (methodDecl == null) {
            // no operation declarated previously in class diagram,
            // warning
            _pipeline
                    .getLogger()
                    .warning(
                            inter.getName()
                                    + " not present in CompilationPackage, not previously declared" );

            return null;
        }

        // update current method declaration being processed
        this.curMethodDeclaration = methodDecl;

        // replace body with new, empty one
        AST ast = methodDecl.getAST();
        Block implBlock = ast.newBlock();

        // generate new method block body
        BlockGenerator blockGenerator = new BlockGenerator( inter, implBlock );
        Block newBlock = blockGenerator.getBlock();
        methodDecl.setBody( newBlock );

        // add JAST mapping
        // add interaction to the mapping, new method block -> Interaction
        _mappings.add( newBlock, inter );

        return methodDecl;
    }

    /**
     * return string in a body of UMLVMexpression comments, or null
     * 
     * @param comment
     *            the comment, to be checked if properly stereotyped and with
     *            body to be extracted
     * @return the string repr. expression or ""
     */
    public Object caseComment( org.eclipse.uml2.Comment comment ) {
        String exprString = "";

        // check if UMLVMexpression
        if (UML2Util.isAppliedStereotype( (Element) comment, Profile.Matilda.UMLVMexpression ) != null) {
            exprString = comment.getBody();
        }

        return exprString;
    }

    // get name of class which method is currently being processed
    protected String getCurrentClassName() {
        if (this.curMethodDeclaration == null) {
            return null;
        }

        CompilationUnit cu = (CompilationUnit) this.curMethodDeclaration.getRoot();

        // assuming one type declaration in cu
        TypeDeclaration typeDecl = (TypeDeclaration) cu.types().get( 0 );
        String typeName = typeDecl.getName().toString();

        return typeName;
    }

    // return an existing MethodDeclaration matching given interaction
    // or null if it does not exists in the CompilationPackage
    private MethodDeclaration getMatchingMethodDecl( Interaction inter, JastCompilationPackage units ) throws MapperException {
        String interName = inter.getName();

        Pattern interNamePattern = Pattern.compile( "^\\s*(.*)\\s*::\\s*(.*)\\s*:\\s*(.*)\\s*$" );
        Matcher interNameMatch = interNamePattern.matcher( interName );

        // try without return name
        if (!interNameMatch.matches()) {
            interNamePattern = Pattern.compile( "^\\s*(.*)\\s*::\\s*(.*)\\s*$" );
            interNameMatch = interNamePattern.matcher( interName );
        }

        if (!interNameMatch.matches()) {
            return null;
        }

        // some name matched
        String jastClassName = null;
        String jastMethodName = null;
        String jastReturnName = null; // optional

        for (int match = 1; match <= interNameMatch.groupCount(); match++) {
            switch (match) {
            case 1:
                jastClassName = interNameMatch.group( match );

                break;

            case 2:
                jastMethodName = interNameMatch.group( match );

                break;

            case 3:
                jastReturnName = interNameMatch.group( match );

                break;

            default:
                break;
            }
        }

        if ((jastClassName == null) || (jastMethodName == null)) {
            _pipeline.getLogger()
                    .warning( "class name or method name not given in SD " + interName );

            return null;
        }

        CompilationUnit unit = units.getUnit( jastClassName );

        // no such compilation unit, no match
        if (unit == null) {
            return null;
        }

        // find the right class decl
        List unitTypes = unit.types();
        TypeDeclaration typeDecl = null;

        for (int i = 0; i < unitTypes.size(); i++) {
            typeDecl = (TypeDeclaration) unitTypes.get( i );

            if (typeDecl.getName().toString().equals( jastClassName )) {
                break;
            }
        }

        if (typeDecl == null) {
            return null;
        }

        if (typeDecl.isInterface()) {
            _pipeline.getLogger().warning(
                    jastClassName + " is an Interface, can't implement method" );

            return null;
        }

        // find matching method decl with the name, params list and type
        // return type
        Type typeRet = null;

        // build return type found in Interaction
        try {
            if (jastReturnName != null) {
                typeRet = TypeBuilder.buildMethodRetType( jastReturnName, unit );
            } else {
                typeRet = TypeBuilder.buildMethodRetType( "", unit );
            }
        } catch (ModelParsingException e) {
            throw new MapperException( inter, e.getMessage() );
        }

        // extract params type list and method name from jastMethodName
        Pattern methodPattern = Pattern.compile( "(.*)\\s*\\(\\s*(.*\\s*\\))" );
        Matcher methodMatch = methodPattern.matcher( jastMethodName );

        String mname = null;
        String mtypes = null;

        if (methodMatch.matches()) {
            for (int match = 1; match <= methodMatch.groupCount(); match++) {
                switch (match) {
                case 1:
                    mname = methodMatch.group( match );

                    break;

                case 2:
                    mtypes = methodMatch.group( match );

                    break;

                default:
                    break;
                }
            }
        } else {
            return null;
        }

        // no method name extracted, no ()
        if ((mname == null) || (mtypes == null)) {
            return null;
        }

        // create a list of Types for parameters
        StringTokenizer tokenizer = new StringTokenizer( mtypes, ",)" );
        ArrayList paramTypes = new ArrayList();

        for (int i = 0; tokenizer.hasMoreTokens(); i++) {
            String typeStr = tokenizer.nextToken();

            // if has a "void", omit, ignore all, empty list
            if (typeStr.equals( "void" )) {
                paramTypes.clear();

                break;
            }

            try {
                Type type = TypeBuilder.buildMethodParamType( typeStr, unit );

                if (type != null) {
                    paramTypes.add( type );
                }
            } catch (ModelParsingException e) {
                throw new MapperException( inter, e.getMessage() );
            }
        }

        // test types
        // finally, match method decl with name, param types and return type
        MethodDeclaration methodDecl = getMatchingMethodDecl( typeDecl, mname, paramTypes, typeRet );

        return methodDecl;
    }

    // return an existing MethodDeclaration matching given method signature
    // or null if it does not exists in the TypeDeclaration
    private MethodDeclaration getMatchingMethodDecl( TypeDeclaration classDecl, String methodName,
            List paramTypes, Type returnType ) {
        MethodDeclaration foundDecl = null;
        MethodDeclaration[] methods = classDecl.getMethods();
        int methods_num = methods.length;

        if (methods_num == 0) // no method declarations
        {
            return null;
        }

        for (int i = 0; i < methods_num; i++) {
            MethodDeclaration mdecl = methods[i];

            // match name
            if (!methodName.equals( mdecl.getName().getIdentifier() )) {
                continue;
            }

            // match return type
            if (!returnType.toString().equals( mdecl.getReturnType().toString() )) {
                continue;
            }

            // match param types
            if (paramTypesMatch( paramTypes, mdecl )) {
                foundDecl = mdecl;

                break;
            }
        }

        return foundDecl;
    }

    // ret. true if types match the parameter list in the MethodDeclaration
    private boolean paramTypesMatch( List types, MethodDeclaration methodDecl ) {
        List parameters = methodDecl.parameters();

        if (types.size() != parameters.size()) {
            return false;
        }

        for (int i = 0; i < types.size(); i++) {
            Type lookType = (Type) types.get( i );
            SingleVariableDeclaration decl = (SingleVariableDeclaration) parameters.get( i );
            Type jastType = (Type) decl.getType();

            if (!(lookType.toString().equals( jastType.toString() ))) {
                return false;
            }
        }

        return true;
    }

    /**
     * 
     * 
     * recursively generate a jast block from every Interaction and elements
     * contained within the Interaction
     * 
     * @author Adam
     * 
     */
    class BlockGenerator {
        private Interaction root; // parent interaction

        private Block block; // parent block

        protected BlockGenerator(Interaction root, Block block) throws MapperException {
            this.root = root;
            this.block = block;
            generate();
        }

        public Block getBlock() {
            return this.block;
        }

        private void generate() throws MapperException {
            generateFromComment();

            EList fragments = root.getFragments();

            for (int i = 0; i < fragments.size(); i++) {
                Element frag = (Element) fragments.get( i );

                if (frag instanceof EventOccurrence) {
                    generateFromEventOccurrence( (EventOccurrence) frag );
                } else if (frag instanceof CombinedFragment) {
                    generateFromCombinedFragment( (CombinedFragment) frag );
                }
            }
        }

        private void generateFromCombinedFragment( CombinedFragment cf ) throws MapperException {
            // extract operator, create a statement
            InteractionOperator operator = cf.getInteractionOperator();

            // Statement statement = null;
            switch (operator.getValue()) {
            case InteractionOperator.OPT:
                generateFromCombinedFragmentOpt( cf );

                break;

            case InteractionOperator.ALT:
                generateFromCombinedFragmentAlt( cf );

                break;

            case InteractionOperator.LOOP:
                generateFromCombinedFragmentLoop( cf );

                break;

            default:
                _pipeline.getLogger().warning(
                        "Unsupported InteractionOperator: " + operator.getName()
                                + " in CombinedFragment in Interaction: " + root.getName() );

                return;
            }
        }

        private void generateFromEventOccurrence( EventOccurrence event ) throws MapperException {
            // only message send from this lifeline
            if (!isEventOnThisLifeline( event )) {
                return;
            }

            // the send EventOccurance is on "this" Lifeline
            Message message = event.getSendMessage();

            if (message == null) {
                return;
            }

            String messageName = message.getName().trim();

            if (UML2Util.isAppliedStereotype( message, "UMLVMexpression" ) != null) {
                generateFromMessageExpression( message );
            } else if (UML2Util.isAppliedStereotype( message, "UMLVMarrayelement" ) != null) {
                generateFromMessageArrayElement( message );
            }

            else if ("return".equals( messageName )) {
                ReturnStatement returnSt = block.getAST().newReturnStatement();
                String exprString = getMessageOpaqueExpression( message );

                // remove ending ;, for more flexibility
                if (exprString != null) {
                    exprString = exprString.replaceAll( ";", "" );
                }

                org.eclipse.jdt.core.dom.Expression returnExpr = null;

                try {
                    returnExpr = buildExpression( block, exprString );
                } catch (ModelParsingException e) {
                    throw new MapperException( message, message.getInteraction(), e.getMessage() );
                }

                try {
                    returnSt.setExpression( returnExpr );
                } catch (IllegalArgumentException e) {
                    throw new MapperException( message, message.getInteraction(),
                            "Illegal Return Statement" );
                }

                block.statements().add( returnSt );

                // add mapping for new node return statement -> Message
                _mappings.add( returnSt, message );
            }

            // either self, or call (new or synchr)
            // check if self message
            else if (UML2Util.isSelfMessage( message )) {
                // assume only one Lifeline covered TODO check
                String selfMessageSt = endStatement( getMessageOpaqueExpression( message ) );
                Block parsedExpr = null;

                try {
                    parsedExpr = buildExpressionStatement( selfMessageSt );
                } catch (ModelParsingException e) {
                    throw new MapperException( message, message.getInteraction(), e.getMessage() );
                }

                // add statements ASTNod to the method body
                List statements = parsedExpr.statements();

                // get only first statement, should only be one !
                if (statements.size() > 0) {
                    Statement statement = (Statement) statements.get( 0 );
                    statement = (Statement) ASTNode.copySubtree( block.getAST(), statement );
                    block.statements().add( statement );

                    // add mapping for new node statement -> (self) Message
                    _mappings.add( statement, message );
                }
            }

            else {
                generateFromMessage( message );
            }
        }

        // called from generateFromEventOccurrence
        // gen from message whose both ends are on different lifelines
        // and is not an UMLVMarrayelement message and return message
        private void generateFromMessage( Message message ) throws MapperException {
            if (message == null) {
                return;
            }

            String messageName = message.getName();

            // get return message via next event occurance
            // from the lifeline sended to
            Message returnMessage = getReturnMessage( message );
            String messageStatement = null;

            if (returnMessage != null) {
                // possibly message call, non "new"
                messageStatement = getMessageOpaqueExpression( returnMessage );
            }

            // check the call message
            else if (getMessageOpaqueExpression( message ) != null) {
                String callMsg = getMessageOpaqueExpression( message );

                // no return message, only "new" calls statement
                // allowed to have code here
                if (callMsg.matches( ".*[\\W\\s]new.*[\\W\\s]" )) {
                    messageStatement = callMsg;
                } else {
                    _pipeline
                            .getLogger()
                            .warning(
                                    callMsg
                                            + " should be in return opaque expression.  Only new allowed here, skipping" );
                }
            }

            if ((messageStatement == null) || messageStatement.equals( "" )) {
                return;
            }

            messageStatement = endStatement( messageStatement );

            Block parsedExpr = null;

            try {
                parsedExpr = buildExpressionStatement( messageStatement );
            } catch (ModelParsingException e) {
                throw new MapperException( message, message.getInteraction(), e.getMessage() );
            }

            // add statement to the method body
            List statements = parsedExpr.statements();

            Statement statement = (Statement) statements.get( 0 );
            statement = (Statement) ASTNode.copySubtree( block.getAST(), statement );
            block.statements().add( statement );

            // add mapping for new node call statement -> Message
            _mappings.add( statement, message );
        }

        // called from generateFromEventOccurrence
        private void generateFromMessageArrayElement( Message message ) throws MapperException {
            String messageName = message.getName();

            Stereotype stereotype = message.getAppliedStereotype( "UMLVMarrayelement" );
            String arrayName = getReceiveObjectName( message );

            if ((arrayName == null) || arrayName.equals( "" )) {
                return;
            }

            // treat as other messages for now -- get the message statement from
            // return
            generateFromMessage( message );
        }

        // called from generateFromEventOccurrence
        private void generateFromMessageExpression( Message message ) throws MapperException {
            String expr = getMessageOpaqueExpression( message );

            Block parsedExpr = null;

            try {
                parsedExpr = buildExpressionStatement( expr );
            } catch (ModelParsingException e) {
                throw new MapperException( message, message.getInteraction(), e.getMessage() );
            }

            // add statements ASTNodes to the method body
            List statements = parsedExpr.statements();

            for (int i = 0; i < statements.size(); i++) {
                Statement statement = (Statement) statements.get( i );
                statement = (Statement) ASTNode.copySubtree( block.getAST(), statement );
                block.statements().add( statement );

                // add mapping for new node return statement -> Message
                _mappings.add( statement, message );
            }
        }

        private void generateFromComment() throws MapperException {
            // add expressions in note attached
            EList comments = root.getOwnedComments();

            if (comments.size() == 0) {
                return;
            }

            StringBuffer interExprBuf = new StringBuffer();

            // use the first (probably only) comment found to create mapping
            org.eclipse.uml2.Comment theFirstComment = null;

            for (int i = 0; i < comments.size(); i++) {
                // skip if something else associated with the Element other than
                // Comment
                if (!(comments.get( i ) instanceof org.eclipse.uml2.Comment)) {
                    continue;
                }

                org.eclipse.uml2.Comment comment = (org.eclipse.uml2.Comment) comments.get( i );
                interExprBuf.append( (String) caseComment( comment ) );

                if (theFirstComment == null) {
                    // needed for mapping
                    theFirstComment = comment;
                }
            }

            String interExprString = interExprBuf.toString().trim();

            // parse expression statements, get body encapsulating
            // put the statements in current method body
            Block interExpr = null;

            try {
                interExpr = buildExpressionStatement( interExprString );
            } catch (ModelParsingException e) {
                throw new MapperException( theFirstComment, root, e.getMessage() );
            }

            // add statements ASTNodes to the method body
            List statements = interExpr.statements();

            for (int i = 0; i < statements.size(); i++) {
                Statement statement = (Statement) statements.get( i );
                statement = (Statement) ASTNode.copySubtree( block.getAST(), statement );
                block.statements().add( statement );

                // add mapping for new node statement -> Comment
                _mappings.add( statement, theFirstComment );
            }
        }

        // TODO add support for more than 2 operands
        private void generateFromCombinedFragmentAlt( CombinedFragment cf ) throws MapperException {
            IfStatement statement = block.getAST().newIfStatement();
            EList operands = cf.getOperands();

            // for each InteractionOperand
            for (int i = 0; i < operands.size(); i++) {
                InteractionOperand interOper = (InteractionOperand) operands.get( i );
                InteractionConstraint guard = interOper.getGuard();

                // get guard string
                String guardExprString = getGuardExpressionString( guard ).trim();

                if (i == 0) {
                    try {
                        org.eclipse.jdt.core.dom.Expression boolExpr = buildExpression( statement,
                                guardExprString );

                        // fill in true if not an expression
                        if (boolExpr == null) {
                            boolExpr = statement.getAST().newBooleanLiteral( true );
                        }

                        statement.setExpression( boolExpr );

                        // add mapping for new node expression -> Guard
                        _mappings.add( boolExpr, guard );
                    } catch (ModelParsingException e) {
                        throw new MapperException( guard, root, e.getMessage() );
                    } catch (IllegalArgumentException e) {
                        throw new MapperException( guard, root, "Illegal expression" );
                    }
                }

                // new body is in Interaction
                // Operand should have only 1 Interaction
                EList interactions = interOper.getFragments();

                if (interactions.size() != 1) {
                } else {
                    Interaction newInteraction = (Interaction) interactions.get( 0 );
                    Block newBlock = block.getAST().newBlock();
                    BlockGenerator blockGenerator = new BlockGenerator(
                            (Interaction) newInteraction, newBlock );

                    if (i == 0) {
                        statement.setThenStatement( blockGenerator.getBlock() );
                    } else {
                        statement.setElseStatement( blockGenerator.getBlock() );
                    }

                    // add mapping for new node new block -> InteractionOperand
                    _mappings.add( blockGenerator.getBlock(), interOper );
                }
            }

            this.block.statements().add( statement );

            // add mapping for new node if statement -> CF
            _mappings.add( statement, cf );
        }

        private void generateFromCombinedFragmentOpt( CombinedFragment cf ) throws MapperException {
            IfStatement statement = block.getAST().newIfStatement();
            EList operands = cf.getOperands();

            // should be only one InteractionOperand
            if (operands.size() > 0) {
                // pick only first
                InteractionOperand interOper = (InteractionOperand) operands.get( 0 );
                InteractionConstraint guard = interOper.getGuard();

                // get guard string
                String guardExprString = getGuardExpressionString( guard );

                try {
                    org.eclipse.jdt.core.dom.Expression boolExpr = buildExpression( statement,
                            guardExprString );

                    // fill in true if not an expression
                    if (boolExpr == null) {
                        boolExpr = statement.getAST().newBooleanLiteral( true );
                    }

                    statement.setExpression( boolExpr );

                    // add mapping for new node expression -> Guard
                    _mappings.add( boolExpr, guard );
                } catch (ModelParsingException e) {
                    throw new MapperException( guard, root, e.getMessage() );
                } catch (IllegalArgumentException e) {
                    throw new MapperException( guard, root, "Illegal Expression" );
                }

                // new body is in Interaction
                // Operand should have only 1 Interaction
                EList interactions = interOper.getFragments();

                if (interactions.size() != 1) {
                } else {
                    Interaction newInteraction = (Interaction) interactions.get( 0 );
                    Block newBlock = block.getAST().newBlock();
                    BlockGenerator blockGenerator = new BlockGenerator(
                            (Interaction) newInteraction, newBlock );
                    statement.setThenStatement( blockGenerator.getBlock() );

                    // add mapping for new node new block -> InteractionOperand
                    _mappings.add( blockGenerator.getBlock(), interOper );
                }

                this.block.statements().add( statement );

                // add mapping for new node if statement -> CF
                _mappings.add( statement, cf );
            }
        }

        private void generateFromCombinedFragmentLoop( CombinedFragment cf ) throws MapperException {
            WhileStatement statement = block.getAST().newWhileStatement();
            EList operands = cf.getOperands();

            // only one InteractionOperand
            if (operands.size() > 0) {
                // pick only first
                InteractionOperand interOper = (InteractionOperand) operands.get( 0 );
                InteractionConstraint guard = interOper.getGuard();

                // get guard string
                String guardExprString = getGuardExpressionString( guard );

                try {
                    org.eclipse.jdt.core.dom.Expression boolExpr = buildExpression( statement,
                            guardExprString );

                    // fill in true if not an expression
                    if (boolExpr == null) {
                        boolExpr = statement.getAST().newBooleanLiteral( true );
                    }

                    statement.setExpression( boolExpr );

                    // add mapping for new node expression -> Guard
                    _mappings.add( boolExpr, guard );
                }

                catch (ModelParsingException e) {
                    throw new MapperException( guard, root, e.getMessage() );
                } catch (IllegalArgumentException e) {
                    throw new MapperException( guard, root, "Illegal Expression" );
                }

                // new body is in Interaction
                // Operand should have only 1 Interaction
                EList interactions = interOper.getFragments();

                if (interactions.size() != 1) {
                } else {
                    Interaction newInteraction = (Interaction) interactions.get( 0 );
                    Block newBlock = block.getAST().newBlock();
                    BlockGenerator blockGenerator = new BlockGenerator(
                            (Interaction) newInteraction, newBlock );
                    statement.setBody( blockGenerator.getBlock() );

                    // add mapping for new node new block -> InteractionOperand
                    _mappings.add( blockGenerator.getBlock(), interOper );
                }

                this.block.statements().add( statement );

                // add mapping for new node while statement -> CF
                _mappings.add( statement, cf );
            }
        }

        // return ast subtree Block encapsulating statements from (single or
        // multiple )string
        // WARNING: it's responsibility of caller to copy this subtree to a
        // different AST that will be owner
        private Block buildExpressionStatement( String expression ) throws ModelParsingException {
            Document document = new Document( expression );
            ASTParser parser = ASTParser.newParser( AST.JLS2 );
            parser.setSource( document.get().toCharArray() );
            parser.setKind( ASTParser.K_STATEMENTS );

            Block stsRoot = (Block) parser.createAST( null );

            IProblem[] probs = ((CompilationUnit) stsRoot.getRoot()).getProblems();
            String problemsMessage = null;

            for (int i = 0; i < probs.length; i++) {
                problemsMessage += (probs[i].getMessage() + "\n");
            }

            if (probs.length > 0) {
                throw new ModelParsingException( expression, probs.length + " problem(s): "
                        + problemsMessage );
            }

            return stsRoot;
        }

        // return ast subtree Expression from a single expression string
        // the expression will be a child of the ast node passed
        private org.eclipse.jdt.core.dom.Expression buildExpression( ASTNode parent,
                String expressionStr ) throws ModelParsingException {
            if ((expressionStr == null) || expressionStr.equals( "" )) {
                return null;
            }

            Document document = new Document( expressionStr );
            ASTParser parser = ASTParser.newParser( AST.JLS2 );
            parser.setSource( document.get().toCharArray() );
            parser.setKind( ASTParser.K_EXPRESSION );

            org.eclipse.jdt.core.dom.Expression expression = null;

            try {
                expression = (org.eclipse.jdt.core.dom.Expression) parser.createAST( null );
            } catch (ClassCastException e) {
                throw new ModelParsingException( expressionStr );
            }

            IProblem[] probs = ((CompilationUnit) expression.getRoot()).getProblems();
            String problemsMessage = null;

            for (int i = 0; i < probs.length; i++) {
                problemsMessage += (probs[i].getMessage() + "\n");
            }

            if (probs.length > 0) {
                throw new ModelParsingException( expressionStr, probs.length + " problem(s): "
                        + problemsMessage );
            }

            expression = (org.eclipse.jdt.core.dom.Expression) ASTNode.copySubtree(
                    parent.getAST(), expression );

            return expression;
        }

        // return true if the event is on "this" Lifeline
        // "this" lifeline coresponds to object of class whose method is
        // currently updated
        private boolean isEventOnThisLifeline( EventOccurrence event ) {
            EList covereds = event.getCovereds();
            String thisName = "this:" + getCurrentClassName();

            boolean isOnThis = false;

            for (int i = 0; i < covereds.size(); i++) {
                Lifeline covered = (Lifeline) covereds.get( i );
                String coveredName = covered.getName();

                // check for match, ignore whitespace
                if (thisName.equals( coveredName.replaceAll( "\\s", "" ) )) {
                    isOnThis = true;

                    break;
                }
            }

            return isOnThis;
        }

        // extract and return String representing guard constraint boolean
        // expression
        // or return "true" String
        private String getGuardExpressionString( InteractionConstraint guard ) {
            if (guard == null) {
                _pipeline.getLogger().warning(
                        "empty guard, defaulting to true in Interaction " + root.getName() );

                return "true";
            }

            // get the first expression (should be only one)
            Expression guardExpr = null;
            EList guardOwned = guard.getOwnedElements();

            for (int i = 0; i < guardOwned.size(); i++) {
                if (guardOwned.get( i ) instanceof Expression) {
                    guardExpr = (Expression) guardOwned.get( i );

                    break;
                }
            }

            String guardExprString;

            if (guardOwned == null) {
                _pipeline.getLogger().warning(
                        "Unspecified guard constraint expression in CombinedFragment in Interaction: "
                                + root.getName() + ", defaulting to true" );
                guardExprString = "true";
            }

            else {
                if (!guardExpr.getLanguage().equalsIgnoreCase( "java" )) {
                    _pipeline.getLogger().warning(
                            "language of guard constraint expression not Java, in CombinedFragment in Interaction: "
                                    + root.getName() + ", forcing Java" );
                }

                guardExprString = guardExpr.getBody();

                if ((guardExprString == null) || guardExprString.trim().equals( "" )) {
                    _pipeline.getLogger().warning(
                            "Unspecified guard constraint expression in CombinedFragment in Interaction: "
                                    + root.getName() + ", defaulting to true" );
                    guardExprString = "true";
                }
            }

            return guardExprString;
        }

        // get String repr. body of the first OpaqueExpression contained in
        // Message
        // (should be only one)
        private String getMessageOpaqueExpression( Message message ) {
            EList elements = message.getOwnedElements();

            OpaqueExpression expr = null;

            for (int i = 0; i < elements.size(); i++) {
                EObject el = (EObject) elements.get( i );

                if (el instanceof OpaqueExpression) {
                    if (!((OpaqueExpression) el).getLanguage().equalsIgnoreCase( "java" )) {
                        _pipeline.getLogger().warning(
                                "Opaque expression language not Java, forcing Java, in Interaction: "
                                        + root.getName() );
                    }

                    expr = (OpaqueExpression) el;

                    break;
                }
            }

            if (expr == null) {
                return null;
            } else {
                return expr.getBody().trim();
            }
        }

        // add a missing ';' to a statement if there isn't any
        // needed before parser
        private String endStatement( String statement ) {
            if ((statement == null) || statement.equals( "" )) {
                return statement;
            }

            statement = statement.trim();

            int len = statement.length();

            if (statement.charAt( len - 1 ) != ';') {
                statement += ";";
            }

            return statement;
        }

        // return name of object at the receiving end
        // either object name before the ":" or the entire name if no ":" for
        // static
        // message must have both ends EventOccurances, on different Lifelines
        private String getReceiveObjectName( Message message ) {
            if ((message.getReceiveEvent() == null)
                    || (!(message.getReceiveEvent() instanceof EventOccurrence))) {
                return null;
            }

            EventOccurrence receiveEvent = (EventOccurrence) message.getReceiveEvent();

            // should be covered by only one lifeline
            EList covereds = receiveEvent.getCovereds();

            if (covereds.size() != 1) {
                return null;
            }

            Lifeline lifeline = (Lifeline) covereds.get( 0 );

            String lifelineName = lifeline.getName().trim();

            int semiIndex = lifelineName.indexOf( ':' );

            if (semiIndex == -1) {
                return lifelineName;
            } else {
                return lifelineName.substring( 0, semiIndex ).trim();
            }
        }

        // return type name Lifeline pointed to
        // either substring name after the ":" or the entire name if no ":"
        // message must have both ends EventOccurances, on different Lifelines
        private String getReceiveTypeName( Message message ) {
            if ((message.getReceiveEvent() == null)
                    || (!(message.getReceiveEvent() instanceof EventOccurrence))) {
                return null;
            }

            EventOccurrence receiveEvent = (EventOccurrence) message.getReceiveEvent();

            // should be covered by only one lifeline
            EList covereds = receiveEvent.getCovereds();

            if (covereds.size() != 1) {
                return null;
            }

            Lifeline lifeline = (Lifeline) covereds.get( 0 );

            String lifelineName = lifeline.getName().trim();

            int semiIndex = lifelineName.indexOf( ':' );

            if (semiIndex == -1) {
                return lifelineName;
            } else {
                return lifelineName.substring( semiIndex + 1 );
            }
        }

        // another method to track the return message, not using
        // ExecutionOccurrences
        // not currently in use due to possible model problems
        private Message getReturnMessage2( Message message ) throws MapperException {
            if ((message.getReceiveEvent() == null)
                    || (!(message.getReceiveEvent() instanceof EventOccurrence))) {
                return null;
            }

            EventOccurrence receiveEvent = (EventOccurrence) message.getReceiveEvent();

            Lifeline lifeline = UML2Util.getLifeline( receiveEvent );

            // get next event after receiveEvent, must be on the same lifeline
            EList fragments = lifeline.getCoveredBys();

            // get an index of receiveEvent
            // MUST BE found
            int rcvIndex = 0;
            boolean found = false;

            for (; rcvIndex < fragments.size(); rcvIndex++) {
                InteractionFragment fragment = (InteractionFragment) fragments.get( rcvIndex );

                if (fragment == receiveEvent) {
                    found = true;

                    break;
                }
            }

            if (!found) {
                throw new MapperException( "impossible error in the model, EventOccurance: "
                        + receiveEvent.getName() + " not registered in the lifeline: "
                        + lifeline.getName() );
            }

            // find the next EventOccurance on this Lifeline after the receive
            // event
            // that connects with message to the lifeline that was sent from
            EventOccurrence returnSend = null;

            for (; rcvIndex < fragments.size(); rcvIndex++) {
                InteractionFragment fragment = (InteractionFragment) fragments.get( rcvIndex );

                if (fragment instanceof EventOccurrence && !(fragment instanceof Stop)
                        && (((EventOccurrence) fragment).getSendMessage() != null)) {
                    Message retmesg = ((EventOccurrence) fragment).getSendMessage();

                    // check if goes back to the same lifeline
                    if (retmesg.getReceiveEvent() instanceof EventOccurrence
                            && !(retmesg.getReceiveEvent() instanceof Stop)) {
                        // check if receive event of potential return message
                        // is on the same lifeline as send event for the message
                        EventOccurrence retrcv = (EventOccurrence) retmesg.getReceiveEvent();

                        Lifeline backlifeline = UML2Util.getLifeline( retrcv );

                        EventOccurrence sendev = (EventOccurrence) message.getSendEvent();

                        if ((UML2Util.getLifeline( sendev ).getName() != null)
                                && UML2Util.getLifeline( sendev ).getName().equals(
                                        backlifeline.getName() )) {
                            // found send event for return message
                            returnSend = (EventOccurrence) fragment;

                            break;
                        }
                    }
                }
            }

            // no return message found
            if (returnSend == null) {
                return null;
            }

            Message returnMessage = returnSend.getSendMessage();

            if (returnMessage == null) {
            }

            return returnMessage;
        }

        // find return message for a message, use ExecutionOccurances
        // TODO if more then 1 start exec occurences, find the right one
        private Message getReturnMessage( Message message ) {
            if ((message.getReceiveEvent() == null)
                    || (!(message.getReceiveEvent() instanceof EventOccurrence))) {
                return null;
            }

            EventOccurrence receiveEvent = (EventOccurrence) message.getReceiveEvent();
            EList execs = receiveEvent.getStartExecs();

            ExecutionOccurrence startExec = null;

            if (execs.size() != 1) {
                if (execs.size() > 1) {
                    _pipeline.getLogger().warning(
                            "Number of ExecutionOccurences in receive event start execs is more than 1 ("
                                    + new Integer( execs.size() ) + "), in Interaction: "
                                    + root.getName() );
                }

                return null;
            }

            startExec = (ExecutionOccurrence) execs.get( 0 );

            EventOccurrence sendRet = startExec.getFinish();

            if (sendRet == null) {
                return null;
            }

            Message returnMessage = sendRet.getSendMessage();

            return returnMessage;
        }
    }
}
