/* Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * Created/refactored on Aug 18, 2005
 * Contributors: EMMadhuBabu, Jun Suzuki
 *
 * If you have any questions on this source code, see
 * http://umlvm.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */

package edu.umb.cs.umlvm.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import edu.umb.cs.umlvm.core.blackboard.Blackboard;
import edu.umb.cs.umlvm.core.config.Config;

public class Pipeline {

    Config _config;
    Blackboard _blackboard;
    Logger _logger;

    public Pipeline(Config config, Blackboard blackboard) {
        _config = config;
        _blackboard = blackboard;
    }

    public Blackboard getBlackboard() {
        return _blackboard;
    }

    public Logger getLogger() {
        return _logger;
    }

    public Config getConfig() {
        return _config;
    }

    public void initialize() {
        try {
            FileHandler handler = new FileHandler( getConfig().getLogFileName() );
            _logger = Logger.getLogger( "UMLVM" );
            _logger.addHandler( handler );
            // log.setLevel(config.getLogLevel());
            _logger.setLevel( Level.OFF );
            // log.setLevel( Level.INFO );
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void start() {
        getLogger().info( "Pipeline Started" );
        getConfig().resetIterator();
        
        boolean hasNext = true;
        while (hasNext) {
            hasNext = executeNextPlugin();
        }
    }

    public boolean executeNextPlugin() {
        try {
            String pluginClassName = getConfig().getNextPluginClass();
            if (pluginClassName == null)
                return false;

            String location = getConfig()
                    .getParam( pluginClassName, "location" );
            if (location == null) {
                getLogger().info( "Now executing: " + pluginClassName );
                Class pluginclass = Class.forName( pluginClassName );
                Object plugininstance = pluginclass.newInstance();
                Class[] parameterTypes;
                Object[] arguments;
                Method executeMethod;

                parameterTypes = new Class[] { Pipeline.class };
                executeMethod = pluginclass.getMethod( "initialize",
                        parameterTypes );
                arguments = new Object[] { this };
                executeMethod.invoke( plugininstance, arguments );

                parameterTypes = new Class[] {};
                executeMethod = pluginclass.getMethod( "execute",
                        parameterTypes );
                arguments = new Object[] {};
                executeMethod.invoke( plugininstance, arguments );
            }
            // TODO: Implement a plugin repository
            /*
             * else { //call the communication manager if
             * (System.getSecurityManager() == null) {
             * System.setSecurityManager(null); } String name = "//" + location +
             * "/CommunicationManager"; CommunicationManagerInterface cm =
             * (CommunicationManagerInterface) Naming.lookup(name);
             * log.info("Executing the remote plugin: "+ pluginClassName);
             * cm.executeNextPlugin(pluginClassName); System.out.println("Done
             * executing the plugin"); executeNextPlugin(); }
             */

        } catch (ClassNotFoundException e) {
            System.out.println( e );
        } catch (NoSuchMethodException e) {
            System.out.println( e );
        } catch (IllegalAccessException e) {
            System.out.println( e );
        } catch (InvocationTargetException e) {
            System.out.println( e.getTargetException().getMessage() );
        } catch (InstantiationException e) {
            System.out.println( e );
        } catch (Exception e) {
            System.out.println( e );
        }

        return true;
    }
}
