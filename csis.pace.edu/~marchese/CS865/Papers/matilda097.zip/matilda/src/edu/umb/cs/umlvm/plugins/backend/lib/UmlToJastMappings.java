/*
 * Copyright 2004-2006 The Distributed Software Systems Group,
 *                     University of Massachusetts, Boston
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * If you have any questions on this source code, see
 * http://dssg.cs.umb.edu/ or email Jun Suzuki at jxs@cs.umb.edu.
 */
package edu.umb.cs.umlvm.plugins.backend.lib;

import org.eclipse.jdt.core.dom.ASTNode;

import org.eclipse.uml2.Element;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

/**
 * @author Adam
 * 
 * represents mappings between UML and JAST made during the mapping process
 * allows for lookup by ASTNode and retrieve UML element from which the node was
 * created
 * 
 * note: the mapping made during translation was 1 -> many therefore many
 * ASTNodes can map map to 1 same UML element
 * 
 * if ASTNode is modified by following plugins after mapping was originally made
 * hashval of ASTNode may change and it is responsibility of new plugin writer
 * to remap
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class UmlToJastMappings implements Serializable {
    private HashMap mappings;

    public UmlToJastMappings() {
        mappings = new HashMap();
    }

    /**
     * record mapping between ast node and uml element
     * 
     * @param astNode -
     *            freshly produced ast node from an element
     * @param umlElement
     */
    public void add( ASTNode astNode, Element umlElement ) {
        mappings.put( astNode, umlElement );
    }

    /**
     * retrieve UML element from which ASTNode was mapped
     * 
     * @return element - UML element
     */
    public Element getUmlElement( ASTNode astNode ) {
        return (Element) mappings.get( astNode );
    }

    /**
     * fix mapping if ASTNode gets modified for example by a subsequent plugin
     * 
     * @param nodeOldVer
     *            old version of the ASTNode
     * @param nodeNewVer
     *            new, updated version of the ASTNode
     * 
     * @return true if remaping succeded (there was an old version)
     */
    public boolean remap( ASTNode nodeOldVer, ASTNode nodeNewVer ) {
        boolean remapped = false;
        Element umlElement = (Element) mappings.get( nodeOldVer );

        if (umlElement != null) {
            mappings.remove( nodeOldVer );
            mappings.put( nodeNewVer, umlElement );
        }

        return remapped;
    }

    /**
     * print the collection of mappings created for debugging
     * 
     */
    public void print() {
        Set keys = mappings.keySet();
        Iterator keysIter = keys.iterator();
        while (keysIter.hasNext()) {
            Object astNode = keysIter.next();
            Object value = mappings.get( astNode );
            // System.out.println ("MAPPING: " + astNode + " --> " + value);
        }

    }

}
