

public class DivideOperator extends Operator {
	public DivideOperator() {
		opStr = "/";
		return;
	}
	public double execute(java.util.Stack outStack) {
		if (outStack.size() < 2) {
			printError("I am a busy man... I need two assistants...");
		}
		ExprToken tok2 = (ExprToken) outStack.pop();
		ExprToken tok1 = (ExprToken) outStack.pop();
		if (!(tok1 instanceof Operand) || !(tok2 instanceof Operand)) {
			printError("Token are not of type Operand!");
		}
		double left = ((Operand) tok1).execute(outStack);
		double right = ((Operand) tok2).execute(outStack);
		if (right == 0) {
			printError("Division by Zero!");
		}
		double doubleres = left / right;
		java.lang.Double result = new java.lang.Double(doubleres);
		outStack.push(new Operand(result));
		return doubleres;
	}
}