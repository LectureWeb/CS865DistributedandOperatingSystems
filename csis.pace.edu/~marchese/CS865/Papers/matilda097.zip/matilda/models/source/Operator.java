

public abstract class Operator implements ExprToken {
	public java.lang.String opStr;
	public Operator() {
	}
	public abstract double execute(java.util.Stack outStack);
	public void printError(java.lang.String err) {
		System.out.println(opStr + " operation error: " + err);
		System.exit(1);
		return;
	}
}