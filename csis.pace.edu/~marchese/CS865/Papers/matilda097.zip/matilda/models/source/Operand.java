

public class Operand implements ExprToken {
	private java.lang.Double value;
	public double execute(java.util.Stack outStack) {
		return value.doubleValue();
	}
	public Operand(java.lang.Double val) {
		value = val;
		return;
	}
}