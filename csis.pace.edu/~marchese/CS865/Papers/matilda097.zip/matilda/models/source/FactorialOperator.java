

public class FactorialOperator extends Operator {
	public FactorialOperator() {
		opStr = "!";
		return;
	}
	public double execute(java.util.Stack outStack) {
		if (outStack.size() < 1) {
			printError("I am a busy man... I need an assistant...");
		}
		ExprToken tok = (ExprToken) outStack.pop();
		if (!(tok instanceof Operand)) {
			printError("Token is not of type Operand!");
		}
		int num = (int) ((Operand) tok).execute(outStack);
		if (num < 0) {
			printError("Operand should be greater or equal to 0!");
		}
		int factorial = 1;
		while (num > 1) {
			factorial = factorial * num;
			num--;
		}
		java.lang.Double result = new java.lang.Double(factorial);
		Operand resultOperand = new Operand(result);
		outStack.push(resultOperand);
		return factorial;
	}
}