

public interface ExprToken {
	public double execute(java.util.Stack outStack);
}