

public class Tokenizer {
	private java.util.HashMap operatorMap;
	private java.lang.String[] exprArr;
	private int currIndex;
	public ExprToken getNextToken() {
		ExprToken nextToken = null;
		if (currIndex < exprArr.length) {
			java.lang.String currTok = exprArr[currIndex];
			if (operatorMap.containsKey(currTok)) {
				nextToken = (ExprToken) operatorMap.get(currTok);
			} else {
				java.lang.Double value = new java.lang.Double(currTok);
				nextToken = new Operand(value);
			}
			currIndex++;
		}
		return nextToken;
	}
	public Tokenizer(java.lang.String[] inputArr) {
		exprArr = inputArr;
		currIndex = 0;
		operatorMap = new java.util.HashMap();
		operatorMap.put("-", new MinusOperator());
		operatorMap.put("+", new PlusOperator());
		operatorMap.put("/", new DivideOperator());
		operatorMap.put("x", new MultiplyOperator());
		operatorMap.put("!", new FactorialOperator());
		return;
	}
}