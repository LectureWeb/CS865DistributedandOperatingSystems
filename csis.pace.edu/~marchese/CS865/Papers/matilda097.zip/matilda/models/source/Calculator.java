

public class Calculator {
	private Tokenizer exprTokenizer;
	private java.util.Stack outputStack;
	public Calculator() {
		outputStack = new java.util.Stack();
		return;
	}
	public java.lang.Double calculate(java.lang.String[] exprArr) {
		ExprToken currToken;
		exprTokenizer = new Tokenizer(exprArr);
		while ((currToken = exprTokenizer.getNextToken()) != null) {
			if (currToken instanceof Operand) {
				outputStack.push(currToken);
			} else {
				Operator op = (Operator) currToken;
				op.execute(outputStack);
			}
		}
		if (outputStack.size() != 1) {
			return null;
		}
		ExprToken lastToken = (ExprToken) outputStack.pop();
		if (!(lastToken instanceof Operand)) {
			return null;
		}
		double res = lastToken.execute(outputStack);
		return new Double(res);
	}
	public static void main(java.lang.String[] args) {
		if (args.length == 0) {
			System.exit(0);
		} else {
			Calculator calc = new Calculator();
			java.lang.Double result = calc.calculate(args);
			if (result == null) {
				System.out.println("Error: Malformed input expression!");
			} else {
				System.out.println("Result: " + result);
			}
		}
		return;
	}
}